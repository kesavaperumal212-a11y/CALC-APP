
import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import { createServer as createViteServer } from "vite";

const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// In-memory store for room data
// In a production app, use a database like MongoDB or PostgreSQL
const roomData: Record<string, any> = {};

io.on("connection", (socket) => {
  console.log("A user connected:", socket.id);

  socket.on("join-room", (roomId: string) => {
    socket.join(roomId);
    console.log(`User ${socket.id} joined room: ${roomId}`);
    
    // Send existing data to the newly joined user
    if (roomData[roomId]) {
      socket.emit("sync-data", roomData[roomId]);
    }
  });

  socket.on("update-data", ({ roomId, data }: { roomId: string, data: any }) => {
    roomData[roomId] = data;
    // Broadcast to everyone else in the room
    socket.to(roomId).emit("sync-data", data);
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
