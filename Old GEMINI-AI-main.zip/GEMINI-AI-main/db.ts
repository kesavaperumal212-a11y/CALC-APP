
import { Party, Item, Transaction, Employee, Attendance, SalaryTransaction, Expense, ExpenseCategory } from './types';

const STORAGE_KEYS = {
  PARTIES: 'ecp_parties',
  ITEMS: 'ecp_items',
  TRANSACTIONS: 'ecp_transactions',
  EMPLOYEES: 'ecp_employees',
  ATTENDANCE: 'ecp_attendance',
  SALARY_TX: 'ecp_salary_tx',
  EXPENSE_CATS: 'ecp_expense_cats',
  EXPENSES: 'ecp_expenses'
};

export const db = {
  saveParties: (parties: Party[]) => localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(parties)),
  getParties: (): Party[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.PARTIES) || '[]'),
  
  saveItems: (items: Item[]) => localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items)),
  getItems: (): Item[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.ITEMS) || '[]'),
  
  saveTransactions: (txs: Transaction[]) => localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(txs)),
  getTransactions: (): Transaction[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.TRANSACTIONS) || '[]'),

  saveEmployees: (employees: Employee[]) => localStorage.setItem(STORAGE_KEYS.EMPLOYEES, JSON.stringify(employees)),
  getEmployees: (): Employee[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.EMPLOYEES) || '[]'),

  saveAttendance: (attendance: Attendance[]) => localStorage.setItem(STORAGE_KEYS.ATTENDANCE, JSON.stringify(attendance)),
  getAttendance: (): Attendance[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.ATTENDANCE) || '[]'),

  saveSalaryTransactions: (txs: SalaryTransaction[]) => localStorage.setItem(STORAGE_KEYS.SALARY_TX, JSON.stringify(txs)),
  getSalaryTransactions: (): SalaryTransaction[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.SALARY_TX) || '[]'),

  saveExpenseCategories: (cats: ExpenseCategory[]) => localStorage.setItem(STORAGE_KEYS.EXPENSE_CATS, JSON.stringify(cats)),
  getExpenseCategories: (): ExpenseCategory[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.EXPENSE_CATS) || '[]'),

  saveExpenses: (expenses: Expense[]) => localStorage.setItem(STORAGE_KEYS.EXPENSES, JSON.stringify(expenses)),
  getExpenses: (): Expense[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.EXPENSES) || '[]'),
};
