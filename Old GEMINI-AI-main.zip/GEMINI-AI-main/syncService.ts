
import { io, Socket } from "socket.io-client";
import { db } from "./db";

class SyncService {
  private socket: Socket | null = null;
  private roomId: string | null = null;
  private onDataReceived: ((data: any) => void) | null = null;
  private onStatusChange: ((connected: boolean, error?: string) => void) | null = null;

  constructor() {
    this.roomId = localStorage.getItem("ecp_sync_room_id");
  }

  connect(onDataReceived: (data: any) => void, onStatusChange?: (connected: boolean, error?: string) => void) {
    this.onDataReceived = onDataReceived;
    if (onStatusChange) this.onStatusChange = onStatusChange;
    
    // Use the current window location for the socket connection
    // Forcing polling first can sometimes be more stable in restricted environments
    this.socket = io({
      transports: ['polling', 'websocket'],
      reconnectionAttempts: 10,
      reconnectionDelay: 2000,
      timeout: 10000,
    });

    this.socket.on("connect", () => {
      console.log("Connected to sync server:", this.socket?.id);
      if (this.onStatusChange) this.onStatusChange(true);
      if (this.roomId) {
        this.socket?.emit("join-room", this.roomId);
      }
    });

    this.socket.on("disconnect", (reason) => {
      console.log("Disconnected from sync server:", reason);
      if (this.onStatusChange) this.onStatusChange(false);
    });

    this.socket.on("connect_error", (error) => {
      console.error("Sync connection error:", error.message);
      if (this.onStatusChange) this.onStatusChange(false, error.message);
    });

    this.socket.on("sync-data", (data: any) => {
      console.log("Received sync data");
      if (this.onDataReceived) {
        this.onDataReceived(data);
      }
    });
  }

  setRoomId(id: string) {
    this.roomId = id;
    localStorage.setItem("ecp_sync_room_id", id);
    if (this.socket?.connected) {
      this.socket.emit("join-room", id);
    }
  }

  getRoomId() {
    return this.roomId;
  }

  broadcastUpdate() {
    if (!this.socket?.connected || !this.roomId) return;

    const data = {
      parties: db.getParties(),
      items: db.getItems(),
      transactions: db.getTransactions(),
      expenses: db.getExpenses(),
      expenseCategories: db.getExpenseCategories(),
      employees: db.getEmployees(),
      attendance: db.getAttendance(),
      salaryTransactions: db.getSalaryTransactions()
    };

    this.socket.emit("update-data", { roomId: this.roomId, data });
  }

  disconnect() {
    this.socket?.disconnect();
  }
}

export const syncService = new SyncService();
