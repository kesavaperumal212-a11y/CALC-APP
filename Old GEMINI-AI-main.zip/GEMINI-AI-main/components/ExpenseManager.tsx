
import React, { useState } from 'react';
import { Expense, ExpenseCategory } from '../types';

interface ExpenseManagerProps {
  expenses: Expense[];
  categories: ExpenseCategory[];
  editingExpense?: Expense | null;
  onAddExpense: (expense: Expense) => void;
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
  onAddCategory: (category: ExpenseCategory) => void;
  onDeleteCategory: (id: string) => void;
  onCancelEdit: () => void;
}

const ExpenseManager: React.FC<ExpenseManagerProps> = ({ 
  expenses, 
  categories, 
  editingExpense,
  onAddExpense, 
  onEditExpense,
  onDeleteExpense, 
  onAddCategory, 
  onDeleteCategory,
  onCancelEdit
}) => {
  const [showCatForm, setShowCatForm] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  
  const [amount, setAmount] = useState(editingExpense?.amount.toString() || '');
  const [selectedCatId, setSelectedCatId] = useState(editingExpense?.categoryId || '');
  const [note, setNote] = useState(editingExpense?.note || '');
  const [date, setDate] = useState(editingExpense?.date.split('T')[0] || new Date().toISOString().split('T')[0]);

  // Update form when editingExpense changes
  React.useEffect(() => {
    if (editingExpense) {
      setAmount(editingExpense.amount.toString());
      setSelectedCatId(editingExpense.categoryId);
      setNote(editingExpense.note || '');
      setDate(editingExpense.date.split('T')[0]);
    } else {
      setAmount('');
      setSelectedCatId('');
      setNote('');
      setDate(new Date().toISOString().split('T')[0]);
    }
  }, [editingExpense]);

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    onAddCategory({
      id: 'CAT-' + Date.now(),
      name: newCatName.trim()
    });
    setNewCatName('');
    setShowCatForm(false);
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !selectedCatId) return;
    
    const category = categories.find(c => c.id === selectedCatId);
    onAddExpense({
      id: editingExpense?.id || 'EXP-' + Date.now(),
      categoryId: selectedCatId,
      categoryName: category?.name || 'Unknown',
      date: new Date(date).toISOString(),
      amount: Number(amount),
      note
    });
    
    if (!editingExpense) {
      setAmount('');
      setNote('');
    }
  };

  return (
    <div className="p-4 space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Expenses</h2>
        <button 
          onClick={() => setShowCatForm(!showCatForm)}
          className={`p-2 rounded-full transition-all ${showCatForm ? 'bg-red-100 text-red-600 rotate-45' : 'bg-indigo-600 text-white shadow-lg'}`}
        >
          <i className="fas fa-tags"></i>
        </button>
      </div>

      {showCatForm && (
        <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-4">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Manage Categories</h3>
          <form onSubmit={handleAddCategory} className="flex gap-2">
            <input 
              type="text"
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              placeholder="New Category Name"
              className="flex-1 p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
            />
            <button type="submit" className="bg-indigo-600 text-white px-4 rounded-2xl font-black text-xs">ADD</button>
          </form>
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <div key={cat.id} className="bg-indigo-50 text-indigo-600 px-3 py-1.5 rounded-full text-[10px] font-black flex items-center gap-2">
                {cat.name}
                <button onClick={() => onDeleteCategory(cat.id)} className="text-indigo-300 hover:text-red-500">
                  <i className="fas fa-times"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <form onSubmit={handleAddExpense} className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{editingExpense ? 'Edit Expense' : 'Add New Expense'}</h3>
          {editingExpense && (
            <button type="button" onClick={onCancelEdit} className="text-[10px] font-black text-red-500 uppercase tracking-widest">Cancel</button>
          )}
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Date</label>
            <input 
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Category</label>
            <select 
              value={selectedCatId}
              onChange={(e) => setSelectedCatId(e.target.value)}
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
              required
            >
              <option value="">Select</option>
              {categories.map(cat => <option key={cat.id} value={cat.id}>{cat.name}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Amount</label>
            <input 
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="₹"
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Note</label>
            <input 
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional"
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
            />
          </div>
        </div>

        <button 
          type="submit"
          className="w-full py-4 bg-indigo-600 text-white font-black text-sm uppercase tracking-widest rounded-[2rem] shadow-lg shadow-indigo-200"
        >
          {editingExpense ? 'Update Expense' : 'Save Expense'}
        </button>
      </form>

      <div className="space-y-3">
        <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Recent Expenses</h3>
        {expenses.length === 0 ? (
          <div className="text-center py-12 text-gray-300 italic text-sm">No expenses recorded yet.</div>
        ) : (
          expenses.slice(0, 20).map(exp => (
            <div key={exp.id} className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
              <div>
                <h4 className="font-black text-gray-800 text-sm">{exp.categoryName}</h4>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                  {new Date(exp.date).toLocaleDateString()} {exp.note && `• ${exp.note}`}
                </p>
              </div>
              <div className="text-right">
                <p className="font-black text-sm text-red-600">₹{exp.amount.toLocaleString('en-IN')}</p>
                <div className="flex gap-2 justify-end">
                  <button onClick={() => onEditExpense(exp)} className="text-gray-200 hover:text-indigo-500">
                    <i className="fas fa-edit text-[10px]"></i>
                  </button>
                  <button onClick={() => onDeleteExpense(exp.id)} className="text-gray-200 hover:text-red-500">
                    <i className="fas fa-trash-alt text-[10px]"></i>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ExpenseManager;
