
import React, { useState, useMemo } from 'react';
import { Employee, Attendance, SalaryTransaction } from '../types';

interface SalaryManagerProps {
  employees: Employee[];
  attendance: Attendance[];
  salaryTransactions: SalaryTransaction[];
  onSaveTransaction: (tx: SalaryTransaction) => void;
  onDeleteTransaction: (id: string) => void;
}

const SalaryManager: React.FC<SalaryManagerProps> = ({ employees, attendance, salaryTransactions, onSaveTransaction, onDeleteTransaction }) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'ADVANCE' | 'SALARY_PAYMENT'>('ADVANCE');
  const [note, setNote] = useState('');

  const selectedEmployee = employees.find(e => e.id === selectedEmployeeId);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployeeId || !amount) return;

    onSaveTransaction({
      id: 'SAL-' + Date.now(),
      employeeId: selectedEmployeeId,
      date: new Date().toISOString(),
      amount: Number(amount),
      type,
      note
    });

    setAmount('');
    setNote('');
    alert('Transaction saved');
  };

  const employeeStats = useMemo(() => {
    if (!selectedEmployeeId) return null;

    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    const monthAttendance = attendance.filter(a => {
      const d = new Date(a.date);
      return a.employeeId === selectedEmployeeId && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const presentShifts = monthAttendance.filter(a => a.status === 'PRESENT').length;
    const halfDayShifts = monthAttendance.filter(a => a.status === 'HALFDAY').length;
    const totalCredits = presentShifts + (halfDayShifts * 0.5);

    const monthSalaryTx = salaryTransactions.filter(t => {
      const d = new Date(t.date);
      return t.employeeId === selectedEmployeeId && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });

    const totalAdvance = monthSalaryTx.filter(t => t.type === 'ADVANCE').reduce((sum, t) => sum + t.amount, 0);
    const totalPaid = monthSalaryTx.filter(t => t.type === 'SALARY_PAYMENT').reduce((sum, t) => sum + t.amount, 0);

    const dailyRate = (selectedEmployee?.salary || 0) / 30;
    const earnedSalary = totalCredits * dailyRate;
    const balance = earnedSalary - totalAdvance - totalPaid;

    return {
      totalCredits,
      earnedSalary,
      totalAdvance,
      totalPaid,
      balance,
      monthName: now.toLocaleString('default', { month: 'long' })
    };
  }, [selectedEmployeeId, attendance, salaryTransactions, selectedEmployee]);

  return (
    <div className="p-4 space-y-6">
      <h2 className="text-xl font-black text-gray-800 tracking-tight">Salary & Advances</h2>

      <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-4">
        <div>
          <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Select Employee</label>
          <select 
            value={selectedEmployeeId}
            onChange={(e) => setSelectedEmployeeId(e.target.value)}
            className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm focus:ring-2 focus:ring-indigo-500 transition-all"
          >
            <option value="">Choose Employee</option>
            {employees.map(emp => <option key={emp.id} value={emp.id}>{emp.name}</option>)}
          </select>
        </div>

        {employeeStats && (
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-indigo-50 p-3 rounded-2xl border border-indigo-100">
              <p className="text-[8px] text-indigo-600 font-black uppercase tracking-tighter">Credits ({employeeStats.monthName})</p>
              <div className="flex items-center gap-2">
                <p className="text-xl font-black text-indigo-700">{employeeStats.totalCredits}</p>
                {employeeStats.totalCredits >= 28 && <i className="fas fa-check-circle text-green-500 text-xs"></i>}
              </div>
            </div>
            <div className="bg-green-50 p-3 rounded-2xl border border-green-100">
              <p className="text-[8px] text-green-600 font-black uppercase tracking-tighter">Earned Salary</p>
              <p className="text-xl font-black text-green-700">₹{Math.round(employeeStats.earnedSalary || 0).toLocaleString('en-IN')}</p>
            </div>
            <div className="bg-red-50 p-3 rounded-2xl border border-red-100">
              <p className="text-[8px] text-red-600 font-black uppercase tracking-tighter">Total Advance</p>
              <p className="text-xl font-black text-red-700">₹{(employeeStats.totalAdvance || 0).toLocaleString('en-IN')}</p>
            </div>
            <div className="bg-orange-50 p-3 rounded-2xl border border-orange-100">
              <p className="text-[8px] text-orange-600 font-black uppercase tracking-tighter">Balance</p>
              <p className="text-xl font-black text-orange-700">₹{Math.round(employeeStats.balance || 0).toLocaleString('en-IN')}</p>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm space-y-4">
        <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Add Transaction</h3>
        
        <div className="flex bg-gray-50 rounded-2xl p-1 border border-gray-100">
          <button 
            type="button"
            onClick={() => setType('ADVANCE')}
            className={`flex-1 py-2 rounded-xl text-[10px] font-black transition-all ${type === 'ADVANCE' ? 'bg-white text-red-600 shadow-sm' : 'text-gray-400'}`}
          >
            ADVANCE
          </button>
          <button 
            type="button"
            onClick={() => setType('SALARY_PAYMENT')}
            className={`flex-1 py-2 rounded-xl text-[10px] font-black transition-all ${type === 'SALARY_PAYMENT' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'}`}
          >
            PAYMENT
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Amount</label>
            <input 
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="₹"
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
              required
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Note</label>
            <input 
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional"
              className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm"
            />
          </div>
        </div>

        <button 
          type="submit"
          className="w-full py-4 bg-indigo-600 text-white font-black text-sm uppercase tracking-widest rounded-[2rem] shadow-lg shadow-indigo-200"
        >
          Save Transaction
        </button>
      </form>

      <div className="space-y-3">
        <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Recent Transactions</h3>
        {salaryTransactions.filter(t => !selectedEmployeeId || t.employeeId === selectedEmployeeId).slice(0, 10).map(tx => {
          const emp = employees.find(e => e.id === tx.employeeId);
          return (
            <div key={tx.id} className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
              <div>
                <h4 className="font-black text-gray-800 text-sm">{emp?.name || 'Unknown'}</h4>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                  {tx.type} • {new Date(tx.date).toLocaleDateString()}
                </p>
              </div>
              <div className="text-right">
                <p className={`font-black text-sm ${tx.type === 'ADVANCE' ? 'text-red-600' : 'text-green-600'}`}>
                  ₹{(tx.amount || 0).toLocaleString('en-IN')}
                </p>
                <button onClick={() => onDeleteTransaction(tx.id)} className="text-gray-200 hover:text-red-500">
                  <i className="fas fa-trash-alt text-[10px]"></i>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SalaryManager;
