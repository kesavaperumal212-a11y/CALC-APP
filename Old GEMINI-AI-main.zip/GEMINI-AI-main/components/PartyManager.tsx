
import React, { useState } from 'react';
import { Party } from '../types';

interface PartyManagerProps {
  parties: Party[];
  onAdd: (party: Party) => void;
  onUpdate: (party: Party) => void;
  onDelete: (id: string) => void;
}

const PartyManager: React.FC<PartyManagerProps> = ({ parties, onAdd, onUpdate, onDelete }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', address: '', phone: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;
    
    if (editingId) {
      onUpdate({ id: editingId, ...formData });
    } else {
      onAdd({ id: Date.now().toString(), ...formData });
    }
    
    setFormData({ name: '', address: '', phone: '' });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (party: Party) => {
    setFormData({ name: party.name, address: party.address || '', phone: party.phone || '' });
    setEditingId(party.id);
    setShowForm(true);
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Parties</h2>
        <button 
          onClick={() => {
            if (showForm) {
              setEditingId(null);
              setFormData({ name: '', address: '', phone: '' });
            }
            setShowForm(!showForm);
          }}
          className={`p-2 rounded-full transition-all ${showForm ? 'bg-red-100 text-red-600 rotate-45' : 'bg-indigo-600 text-white shadow-lg'}`}
        >
          <i className="fas fa-plus"></i>
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-8 bg-gray-50 p-5 rounded-2xl border border-gray-200 shadow-inner space-y-4">
          <h3 className="text-sm font-bold uppercase text-gray-500 mb-2">{editingId ? 'Edit Party' : 'Add New Party'}</h3>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Party Name *</label>
            <input 
              required
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="Full Name"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Address</label>
            <input 
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="City/Street"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Phone Number</label>
            <input 
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.phone}
              onChange={(e) => setFormData({...formData, phone: e.target.value})}
              placeholder="+91..."
            />
          </div>
          <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-md">
            {editingId ? 'Update Party' : 'Save Party'}
          </button>
        </form>
      )}

      <div className="space-y-3">
        {parties.length === 0 ? (
          <p className="text-center text-gray-400 italic py-10">No parties added yet.</p>
        ) : (
          parties.map(p => (
            <div key={p.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-start group">
              <div>
                <h3 className="font-bold text-gray-800">{p.name}</h3>
                {p.address && <p className="text-xs text-gray-500"><i className="fas fa-map-marker-alt mr-1"></i>{p.address}</p>}
                {p.phone && <p className="text-xs text-gray-500"><i className="fas fa-phone mr-1"></i>{p.phone}</p>}
              </div>
              <div className="flex gap-1">
                <button 
                  onClick={() => handleEdit(p)}
                  className="text-gray-300 hover:text-indigo-500 transition-all p-2"
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button 
                  onClick={() => onDelete(p.id)}
                  className="text-gray-300 hover:text-red-500 transition-all p-2"
                >
                  <i className="fas fa-trash-alt"></i>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default PartyManager;
