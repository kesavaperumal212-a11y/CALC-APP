
import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType, SalaryTransaction, Expense } from '../types.ts';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Capacitor } from '@capacitor/core';

interface ReportManagerProps {
  transactions: Transaction[];
  salaryTransactions: SalaryTransaction[];
  expenses: Expense[];
}

const ReportManager: React.FC<ReportManagerProps> = ({ transactions, salaryTransactions, expenses }) => {
  const [filterType, setFilterType] = useState<'ALL' | 'SALE' | 'PURCHASE'>('ALL');
  const [search, setSearch] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const reportData = useMemo(() => {
    const flattenedTransactions = transactions.flatMap(tx => 
      tx.items.map(item => ({
        txId: tx.id,
        date: tx.date,
        type: tx.type as 'SALE' | 'PURCHASE',
        party: tx.partyName,
        itemName: item.itemName,
        bags: item.bags,
        kg: item.kgPerBag || '-',
        rate: item.rate,
        total: item.total,
        isExpense: false
      }))
    );

    const flattenedExpenses = expenses.map(exp => ({
      txId: exp.id,
      date: exp.date,
      type: 'PURCHASE' as const,
      party: 'EXPENSE',
      itemName: exp.categoryName,
      bags: 0,
      kg: '-',
      rate: exp.amount,
      total: exp.amount,
      isExpense: true,
      note: exp.note
    }));

    const flattenedSalaries = salaryTransactions.map(sal => ({
      txId: sal.id,
      date: sal.date,
      type: 'PURCHASE' as const,
      party: 'STAFF SALARY',
      itemName: sal.type,
      bags: 0,
      kg: '-',
      rate: sal.amount,
      total: sal.amount,
      isExpense: true,
      note: sal.note
    }));

    const combined = [...flattenedTransactions, ...flattenedExpenses, ...flattenedSalaries];

    return combined.filter(row => {
      const rowDate = row.date.split('T')[0];
      const matchesType = filterType === 'ALL' || row.type === filterType;
      const matchesSearch = row.party.toLowerCase().includes(search.toLowerCase()) || 
                          row.itemName.toLowerCase().includes(search.toLowerCase());
      const matchesFromDate = !fromDate || rowDate >= fromDate;
      const matchesToDate = !toDate || rowDate <= toDate;
      
      return matchesType && matchesSearch && matchesFromDate && matchesToDate;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transactions, salaryTransactions, expenses, filterType, search, fromDate, toDate]);

  const stats = useMemo(() => {
    return reportData.reduce((acc, row) => {
      if (row.type === 'SALE') acc.sales += row.total;
      else acc.purchases += row.total;
      return acc;
    }, { sales: 0, purchases: 0 });
  }, [reportData]);

  const handleExportPDF = async () => {
    if (reportData.length === 0) {
      alert("No data to export");
      return;
    }

    setIsExporting(true);
    try {
      const doc = new jsPDF();
      
      // Add Title
      doc.setFontSize(18);
      doc.text('SRI ABIRAMI RICE INDUSTRIES', 14, 20);
      doc.setFontSize(12);
      doc.text('Business Earning Report', 14, 28);
      doc.setFontSize(10);
      doc.text(`Period: ${fromDate || 'All Time'} to ${toDate || 'Today'}`, 14, 35);

      // Add Summary
      doc.setFontSize(11);
      doc.text(`Total Sales: Rs. ${stats.sales.toLocaleString('en-IN')}`, 14, 45);
      doc.text(`Total Purchase: Rs. ${stats.purchases.toLocaleString('en-IN')}`, 14, 51);
      doc.text(`Net Earning: Rs. ${(stats.sales - stats.purchases).toLocaleString('en-IN')}`, 14, 57);

      // Add Table
      // Sort chronologically (oldest first) for PDF
      const sortedForPDF = [...reportData].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      const tableRows = sortedForPDF.map(row => [
        new Date(row.date).toLocaleDateString(),
        row.party,
        row.itemName,
        row.bags > 0 ? row.bags : (row.isExpense ? 'Exp' : '-'),
        row.type === 'SALE' ? row.total.toLocaleString('en-IN') : '-',
        row.type === 'PURCHASE' ? row.total.toLocaleString('en-IN') : '-'
      ]);

      autoTable(doc, {
        startY: 65,
        head: [['Date', 'Party', 'Item', 'Bags', 'Sale', 'Purchase']],
        body: tableRows,
        theme: 'grid',
        headStyles: { fillColor: [79, 70, 229] }, // Indigo-600
        styles: { fontSize: 8 },
        columnStyles: {
          4: { halign: 'right' },
          5: { halign: 'right' }
        }
      });

      const fileName = `Report_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Handle Capacitor/Mobile APK
      if (Capacitor.isNativePlatform()) {
        try {
          const pdfBase64 = doc.output('datauristring').split(',')[1];
          
          // Save to temporary file
          const savedFile = await Filesystem.writeFile({
            path: fileName,
            data: pdfBase64,
            directory: Directory.Cache
          });

          // Share the file
          await Share.share({
            title: 'Business Report',
            text: 'SRI ABIRAMI RICE INDUSTRIES Report',
            url: savedFile.uri,
          });
          return;
        } catch (capError) {
          console.error('Capacitor Share Error:', capError);
          // Fallback to web share if plugin fails
        }
      }

      // Web Fallback: Native Share
      const pdfOutput = doc.output('blob');
      if (navigator.canShare && navigator.share) {
        const file = new File([pdfOutput], fileName, { type: 'application/pdf' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: 'Business Report',
            text: 'SRI ABIRAMI RICE INDUSTRIES Report'
          });
          return;
        }
      }

      // Final Fallback: Download
      doc.save(fileName);

    } catch (error) {
      console.error('PDF Export error:', error);
      alert('PDF generation failed.');
    } finally {
      setIsExporting(false);
    }
  };

  const handleShareSummary = async () => {
    const summaryText = `
*BUSINESS EARNING REPORT*
Period: ${fromDate || 'All Time'} to ${toDate || 'Today'}
---------------------------
TOTAL SALES: ₹${stats.sales.toLocaleString('en-IN')}
TOTAL PURCHASE: ₹${stats.purchases.toLocaleString('en-IN')}
NET EARNING: ₹${(stats.sales - stats.purchases).toLocaleString('en-IN')}
---------------------------
Generated via Earning Pro
    `.trim();

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Business Summary',
          text: summaryText
        });
      } catch (e) {
        await navigator.clipboard.writeText(summaryText);
        alert('Summary copied to clipboard!');
      }
    } else {
      await navigator.clipboard.writeText(summaryText);
      alert('Summary copied to clipboard!');
    }
  };

  return (
    <div className="flex flex-col h-full bg-white relative animate-in slide-in-from-right duration-300">
      <div className="p-4 bg-gray-50/80 backdrop-blur-md border-b border-gray-100 sticky top-0 z-10 space-y-4 shadow-sm pb-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-black text-gray-800 tracking-tight uppercase">
            Analysis
          </h2>
          <button onClick={() => {setSearch(''); setFromDate(''); setToDate(''); setFilterType('ALL');}} className="text-[10px] font-black text-indigo-600 uppercase bg-indigo-50 px-3 py-1 rounded-full active:scale-90 transition-transform">
            Reset
          </button>
        </div>
        
        <div className="space-y-3">
          <div className="relative">
            <i className="fas fa-search absolute left-4 top-3.5 text-gray-300 text-sm"></i>
            <input className="w-full pl-11 pr-4 py-3 bg-white border border-gray-100 rounded-2xl text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all" placeholder="Search party, item..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-gray-400 uppercase ml-1">From Date</label>
              <input type="date" className="w-full p-2.5 bg-white border border-gray-100 rounded-xl text-xs outline-none" value={fromDate} onChange={(e) => setFromDate(e.target.value)} />
            </div>
            <div className="space-y-1">
              <label className="text-[9px] font-black text-gray-400 uppercase ml-1">To Date</label>
              <input type="date" className="w-full p-2.5 bg-white border border-gray-100 rounded-xl text-xs outline-none" value={toDate} onChange={(e) => setToDate(e.target.value)} />
            </div>
          </div>

          <div className="flex bg-gray-200/50 rounded-2xl p-1 gap-1">
            {['ALL', 'SALE', 'PURCHASE'].map(t => (
              <button key={t} onClick={() => setFilterType(t as any)} className={`flex-1 py-2 text-[10px] font-black rounded-xl uppercase transition-all ${filterType === t ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400'}`}>
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="overflow-auto flex-1 pb-32">
        <div className="grid grid-cols-3 gap-3 p-4">
          <div className="bg-green-50 p-3 rounded-2xl border border-green-100 flex flex-col items-center">
            <span className="text-[8px] text-green-600 font-black uppercase tracking-widest">Sales</span>
            <span className="text-sm font-black">₹{(stats.sales || 0).toLocaleString('en-IN')}</span>
          </div>
          <div className="bg-red-50 p-3 rounded-2xl border border-red-100 flex flex-col items-center">
            <span className="text-[8px] text-red-600 font-black uppercase tracking-widest">Purchase</span>
            <span className="text-sm font-black">₹{(stats.purchases || 0).toLocaleString('en-IN')}</span>
          </div>
          <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg flex flex-col items-center text-white">
            <span className="text-[8px] font-black uppercase tracking-widest opacity-80">Net Earn</span>
            <span className="text-sm font-black">₹{(stats.sales - stats.purchases || 0).toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="overflow-x-auto border-t border-gray-100">
          <table className="min-w-full border-collapse">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr className="text-left text-[9px] text-gray-400 uppercase font-black">
                <th className="p-4 whitespace-nowrap">Entry</th>
                <th className="p-4 whitespace-nowrap">Details</th>
                <th className="p-4 text-right whitespace-nowrap">Sale</th>
                <th className="p-4 text-right whitespace-nowrap">Purchase/Exp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {reportData.map((row, idx) => (
                <tr key={idx} className="active:bg-indigo-50 transition-colors">
                  <td className="p-4 whitespace-nowrap">
                    <div className="text-[10px] text-gray-400 font-bold mb-0.5">{new Date(row.date).toLocaleDateString([], {month:'short', day:'numeric'})}</div>
                    <div className="font-black text-gray-800 text-xs">{row.party}</div>
                  </td>
                  <td className="p-4 whitespace-nowrap">
                    <div className="text-xs text-gray-600 font-medium">{row.itemName}</div>
                    <div className="text-[9px] text-gray-400 uppercase">{row.bags > 0 ? `${row.bags} Bags` : row.isExpense ? 'Expense' : ''}</div>
                  </td>
                  <td className="p-4 text-right font-black text-sm text-green-600 whitespace-nowrap">
                    {row.type === 'SALE' ? `₹${(row.total || 0).toLocaleString('en-IN')}` : '-'}
                  </td>
                  <td className="p-4 text-right font-black text-sm text-red-600 whitespace-nowrap">
                    {row.type === 'PURCHASE' ? `₹${(row.total || 0).toLocaleString('en-IN')}` : '-'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {reportData.length === 0 && (
          <div className="py-20 text-center">
            <i className="fas fa-folder-open text-4xl text-gray-100 mb-4"></i>
            <p className="text-gray-300 italic text-sm">No records found.</p>
          </div>
        )}
      </div>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-24 right-6 flex flex-col gap-4 z-30">
        <button 
          onClick={handleExportPDF} 
          disabled={isExporting}
          className={`${isExporting ? 'bg-gray-400' : 'bg-red-600'} text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center active:scale-90 transition-all border-4 border-white`}
          title="Export PDF"
        >
          {isExporting ? (
            <i className="fas fa-spinner fa-spin text-xl"></i>
          ) : (
            <i className="fas fa-file-pdf text-xl"></i>
          )}
        </button>
        <button 
          onClick={handleShareSummary} 
          className="bg-indigo-600 text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center active:scale-90 transition-all border-4 border-white"
          title="Share Summary"
        >
          <i className="fas fa-share-nodes text-xl"></i>
        </button>
      </div>
    </div>
  );
};

export default ReportManager;
