
import React, { useState, useMemo } from 'react';
import { Employee, Attendance } from '../types';

interface AttendanceManagerProps {
  employees: Employee[];
  attendance: Attendance[];
  onSave: (records: Attendance[]) => void;
  onManageEmployees: () => void;
}

const AttendanceManager: React.FC<AttendanceManagerProps> = ({ employees, attendance, onSave, onManageEmployees }) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<Attendance['status']>('PRESENT');
  const [markingShift, setMarkingShift] = useState<'MORNING' | 'NIGHT' | 'BOTH'>('MORNING');
  const [localAttendance, setLocalAttendance] = useState<Attendance[]>([]);
  const [viewMode, setViewMode] = useState<'mark' | 'calendar'>('mark');

  // Calendar state
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  // Initialize local attendance when date changes
  useMemo(() => {
    const recordsForDate = attendance.filter(a => a.date.split('T')[0] === selectedDate);
    setLocalAttendance(recordsForDate);
  }, [selectedDate, attendance]);

  const handleAddAttendance = () => {
    if (!selectedEmployee) return;
    
    const shiftsToMark: ('MORNING' | 'NIGHT')[] = markingShift === 'BOTH' ? ['MORNING', 'NIGHT'] : [markingShift];
    
    const newEntries = shiftsToMark.map(shift => ({
      id: `ATT-${selectedEmployee.id}-${selectedDate}-${shift}`,
      employeeId: selectedEmployee.id,
      employeeName: selectedEmployee.name,
      date: new Date(selectedDate).toISOString(),
      status: selectedStatus,
      shift: shift
    }));

    setLocalAttendance(prev => {
      const filtered = prev.filter(p => 
        !(p.employeeId === selectedEmployee.id && shiftsToMark.includes(p.shift))
      );
      return [...filtered, ...newEntries];
    });
    
    setSelectedEmployee(null);
  };

  const handleSave = () => {
    onSave(localAttendance);
    alert(`Attendance saved for ${selectedDate}`);
  };

  const stats = useMemo(() => {
    return {
      present: localAttendance.filter(r => r.status === 'PRESENT').length,
      absent: localAttendance.filter(r => r.status === 'ABSENT').length,
      halfday: localAttendance.filter(r => r.status === 'HALFDAY').length,
      late: localAttendance.filter(r => r.status === 'LATE').length,
    };
  }, [localAttendance]);

  // Calendar logic
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
  const monthName = new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long' });

  const calendarDays = useMemo(() => {
    const days = [];
    for (let i = 0; i < firstDayOfMonth; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(i);
    return days;
  }, [currentMonth, currentYear, daysInMonth, firstDayOfMonth]);

  const getDayAttendance = (day: number) => {
    if (!day) return null;
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const records = attendance.filter(a => a.date.split('T')[0] === dateStr);
    if (records.length === 0) return null;
    
    const presentCount = records.filter(r => r.status === 'PRESENT').length;
    const totalCount = employees.length * 2; // Morning + Night
    
    return {
      present: presentCount,
      total: totalCount,
      records
    };
  };

  return (
    <div className="p-4 space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Attendance</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setViewMode(viewMode === 'mark' ? 'calendar' : 'mark')}
            className="p-2 text-indigo-600 bg-indigo-50 rounded-full active:scale-90 transition-transform"
          >
            <i className={`fas ${viewMode === 'mark' ? 'fa-calendar-days' : 'fa-list-check'}`}></i>
          </button>
          <button 
            onClick={onManageEmployees}
            className="p-2 text-gray-400 hover:text-indigo-600 active:scale-90 transition-transform"
          >
            <i className="fas fa-user-gear"></i>
          </button>
        </div>
      </div>

      {viewMode === 'mark' ? (
        <>
          <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-5">
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Date</label>
                <input 
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full p-3 border border-gray-100 rounded-2xl bg-gray-50 font-bold text-gray-700 text-sm focus:ring-2 focus:ring-indigo-500 transition-all"
                />
              </div>
            </div>

            <div className="bg-indigo-50/30 p-4 rounded-2xl border border-indigo-100 space-y-3">
              <h3 className="text-[10px] font-black text-indigo-900 uppercase tracking-widest">
                {selectedEmployee ? `Marking: ${selectedEmployee.name}` : 'Select an employee below'}
              </h3>
              
              {selectedEmployee && (
                <div className="space-y-3 animate-in slide-in-from-top-2 duration-300">
                  <div>
                    <label className="block text-[8px] font-black text-indigo-400 uppercase mb-1">Select Shift</label>
                    <div className="flex bg-white rounded-xl p-1 border border-indigo-100">
                      {(['MORNING', 'NIGHT', 'BOTH'] as const).map(s => (
                        <button 
                          key={s}
                          onClick={() => setMarkingShift(s)}
                          className={`flex-1 py-1.5 rounded-lg text-[9px] font-black transition-all ${markingShift === s ? 'bg-indigo-600 text-white shadow-md' : 'text-indigo-300'}`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-[8px] font-black text-indigo-400 uppercase mb-1">Status</label>
                    <select 
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value as Attendance['status'])}
                      className="w-full p-2 border border-indigo-100 rounded-xl bg-white text-xs font-bold"
                    >
                      <option value="PRESENT">Present</option>
                      <option value="ABSENT">Absent</option>
                      <option value="HALFDAY">Half Day</option>
                      <option value="LATE">Late</option>
                    </select>
                  </div>

                  <button 
                    onClick={handleAddAttendance}
                    className="w-full py-2.5 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-200 active:scale-95 transition-all"
                  >
                    Add Attendance
                  </button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-4 gap-2 pt-2">
              <div className="bg-green-50/50 p-3 rounded-2xl text-center border border-green-100/50">
                <p className="text-[8px] text-green-600 font-black uppercase tracking-tighter">Present</p>
                <p className="text-xl font-black text-green-700">{stats.present}</p>
              </div>
              <div className="bg-red-50/50 p-3 rounded-2xl text-center border border-red-100/50">
                <p className="text-[8px] text-red-600 font-black uppercase tracking-tighter">Absent</p>
                <p className="text-xl font-black text-red-700">{stats.absent}</p>
              </div>
              <div className="bg-orange-50/50 p-3 rounded-2xl text-center border border-orange-100/50">
                <p className="text-[8px] text-orange-600 font-black uppercase tracking-tighter">Half</p>
                <p className="text-xl font-black text-orange-700">{stats.halfday}</p>
              </div>
              <div className="bg-blue-50/50 p-3 rounded-2xl text-center border border-blue-100/50">
                <p className="text-[8px] text-blue-600 font-black uppercase tracking-tighter">Late</p>
                <p className="text-xl font-black text-blue-700">{stats.late}</p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Employee List</h4>
            {employees.map(emp => {
              const markedShifts = localAttendance.filter(a => a.employeeId === emp.id).map(a => a.shift);
              return (
                <div 
                  key={emp.id} 
                  onClick={() => setSelectedEmployee(emp)}
                  className={`bg-white p-4 rounded-3xl border transition-all cursor-pointer ${selectedEmployee?.id === emp.id ? 'border-indigo-600 ring-2 ring-indigo-100' : 'border-gray-100 shadow-sm'}`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-black text-gray-800 text-sm">{emp.name}</h3>
                      <div className="flex gap-1 mt-1">
                        {markedShifts.length > 0 ? (
                          markedShifts.map(s => (
                            <span key={s} className="text-[7px] font-black bg-indigo-50 text-indigo-500 px-1.5 py-0.5 rounded uppercase">{s}</span>
                          ))
                        ) : (
                          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Not marked</p>
                        )}
                      </div>
                    </div>
                    {markedShifts.length === 2 && (
                      <i className="fas fa-check-double text-green-500"></i>
                    )}
                    {markedShifts.length === 1 && (
                      <i className="fas fa-check-circle text-indigo-400"></i>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="space-y-3 pt-4">
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Entries for {selectedDate}</h4>
            {localAttendance.length === 0 ? (
              <div className="text-center py-12 text-gray-300 italic text-sm">
                No entries added for this date yet.
              </div>
            ) : (
              localAttendance.map((record) => (
                <div key={record.id} className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center active:bg-gray-50 transition-colors">
                  <div>
                    <h3 className="font-black text-gray-800 text-sm">{record.employeeName}</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{record.shift} SHIFT</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                      record.status === 'PRESENT' ? 'bg-green-100 text-green-700' :
                      record.status === 'ABSENT' ? 'bg-red-100 text-red-700' :
                      record.status === 'HALFDAY' ? 'bg-orange-100 text-orange-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {record.status}
                    </span>
                    <button onClick={() => {
                      setLocalAttendance(prev => prev.filter(p => p.id !== record.id));
                    }} className="text-gray-300 hover:text-red-500">
                      <i className="fas fa-times-circle"></i>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {localAttendance.length > 0 && (
            <button 
              onClick={handleSave}
              className="w-full py-5 bg-indigo-600 text-white font-black text-sm uppercase tracking-widest rounded-[2rem] shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95"
            >
              Save All Attendance
            </button>
          )}
        </>
      ) : (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-100/50">
            <div className="flex justify-between items-center mb-6">
              <button onClick={() => setCurrentMonth(prev => prev === 0 ? 11 : prev - 1)} className="p-2 text-gray-400"><i className="fas fa-chevron-left"></i></button>
              <h3 className="font-black text-gray-800 uppercase tracking-widest text-sm">{monthName} {currentYear}</h3>
              <button onClick={() => setCurrentMonth(prev => prev === 11 ? 0 : prev + 1)} className="p-2 text-gray-400"><i className="fas fa-chevron-right"></i></button>
            </div>
            
            <div className="grid grid-cols-7 gap-1 text-center mb-2">
              {['S','M','T','W','T','F','S'].map(d => <div key={d} className="text-[10px] font-black text-gray-300">{d}</div>)}
            </div>
            
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((day, idx) => {
                const data = day ? getDayAttendance(day) : null;
                const isToday = day && new Date().getDate() === day && new Date().getMonth() === currentMonth && new Date().getFullYear() === currentYear;
                
                return (
                  <div 
                    key={idx} 
                    onClick={() => {
                      if (day) {
                        const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                        setSelectedDate(dateStr);
                        setViewMode('mark');
                      }
                    }}
                    className={`aspect-square flex flex-col items-center justify-center rounded-xl transition-all cursor-pointer ${
                      !day ? 'opacity-0' : 
                      isToday ? 'bg-indigo-600 text-white ring-4 ring-indigo-100' :
                      data ? 'bg-indigo-50 text-indigo-700' : 'bg-gray-50 text-gray-400'
                    }`}
                  >
                    <span className="text-[10px] font-black">{day}</span>
                    {data && (
                      <div className="flex gap-0.5 mt-0.5">
                        <div className="w-1 h-1 rounded-full bg-indigo-400"></div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Monthly Summary</h4>
            <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm divide-y divide-gray-50">
              {employees.map(emp => {
                const monthRecords = attendance.filter(a => {
                  const d = new Date(a.date);
                  return a.employeeId === emp.id && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
                });
                const presentCount = monthRecords.filter(r => r.status === 'PRESENT').length;
                
                return (
                  <div key={emp.id} className="py-3 flex justify-between items-center">
                    <span className="text-sm font-bold text-gray-700">{emp.name}</span>
                    <div className="text-right">
                      <span className="text-xs font-black text-indigo-600">{presentCount} Days</span>
                      <p className="text-[8px] text-gray-400 font-bold uppercase">Present this month</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceManager;
