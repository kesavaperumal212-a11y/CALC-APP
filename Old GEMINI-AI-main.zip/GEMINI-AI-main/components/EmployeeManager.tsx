
import React, { useState } from 'react';
import { Employee } from '../types';

interface EmployeeManagerProps {
  employees: Employee[];
  onAdd: (employee: Employee) => void;
  onUpdate: (employee: Employee) => void;
  onDelete: (id: string) => void;
  onBack: () => void;
}

const EmployeeManager: React.FC<EmployeeManagerProps> = ({ employees, onAdd, onUpdate, onDelete, onBack }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', phone: '', salary: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingId) {
      onUpdate({
        id: editingId,
        name: formData.name,
        phone: formData.phone,
        salary: formData.salary ? Number(formData.salary) : undefined
      });
    } else {
      onAdd({
        id: Date.now().toString(),
        name: formData.name,
        phone: formData.phone,
        salary: formData.salary ? Number(formData.salary) : undefined
      });
    }

    setFormData({ name: '', phone: '', salary: '' });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (emp: Employee) => {
    setFormData({
      name: emp.name,
      phone: emp.phone || '',
      salary: emp.salary?.toString() || ''
    });
    setEditingId(emp.id);
    setShowForm(true);
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 text-gray-400 hover:text-indigo-600">
            <i className="fas fa-arrow-left"></i>
          </button>
          <h2 className="text-xl font-bold text-gray-800">Employees</h2>
        </div>
        <button 
          onClick={() => {
            if (showForm) {
              setEditingId(null);
              setFormData({ name: '', phone: '', salary: '' });
            }
            setShowForm(!showForm);
          }}
          className={`p-2 rounded-full transition-all ${showForm ? 'bg-red-100 text-red-600 rotate-45' : 'bg-indigo-600 text-white shadow-lg'}`}
        >
          <i className="fas fa-plus"></i>
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-8 bg-gray-50 p-5 rounded-2xl border border-gray-200 shadow-inner space-y-4">
          <h3 className="text-sm font-bold uppercase text-gray-500 mb-2">
            {editingId ? 'Edit Employee' : 'Add New Employee'}
          </h3>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Name *</label>
            <input 
              required
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="Full Name"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Phone</label>
            <input 
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.phone}
              onChange={(e) => setFormData({...formData, phone: e.target.value})}
              placeholder="Phone Number"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Monthly Salary</label>
            <input 
              type="number"
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.salary}
              onChange={(e) => setFormData({...formData, salary: e.target.value})}
              placeholder="e.g. 15000"
            />
          </div>
          <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-md">
            {editingId ? 'Update Employee' : 'Save Employee'}
          </button>
        </form>
      )}

      <div className="space-y-3">
        {employees.length === 0 ? (
          <p className="text-center text-gray-400 italic py-10">No employees added yet.</p>
        ) : (
          employees.map(emp => (
            <div key={emp.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center group">
              <div>
                <h3 className="font-bold text-gray-800">{emp.name}</h3>
                <div className="flex gap-3 mt-1">
                  {emp.phone && <p className="text-[10px] text-gray-500"><i className="fas fa-phone mr-1"></i>{emp.phone}</p>}
                  {emp.salary && <p className="text-[10px] text-indigo-500 font-bold">₹{(emp.salary || 0).toLocaleString('en-IN')}/mo</p>}
                </div>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleEdit(emp)}
                  className="text-gray-300 hover:text-indigo-500 p-2 transition-colors"
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button 
                  onClick={() => onDelete(emp.id)}
                  className="text-gray-300 hover:text-red-500 p-2 transition-colors"
                >
                  <i className="fas fa-trash-alt"></i>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default EmployeeManager;
