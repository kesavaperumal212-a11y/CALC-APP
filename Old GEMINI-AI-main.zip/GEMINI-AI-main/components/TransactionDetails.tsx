
import React from 'react';
import { Transaction, TransactionType } from '../types.ts';

interface TransactionDetailsProps {
  transaction: Transaction;
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onBack: () => void;
}

const TransactionDetails: React.FC<TransactionDetailsProps> = ({ transaction, onEdit, onDelete, onBack }) => {
  return (
    <div className="p-4 space-y-6 animate-in slide-in-from-bottom duration-300">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 bg-gray-100 rounded-full text-gray-600 active:scale-90 transition-transform">
          <i className="fas fa-arrow-left"></i>
        </button>
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Transaction Details</h2>
      </div>

      <div className="bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-xl shadow-gray-100/50 space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <span className={`text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-widest ${transaction.type === TransactionType.SALE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {transaction.type}
            </span>
            <h3 className="text-2xl font-black text-gray-800 mt-2">{transaction.partyName}</h3>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">{new Date(transaction.date).toLocaleDateString(undefined, { dateStyle: 'full' })}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Grand Total</p>
            <p className={`text-3xl font-black ${transaction.type === TransactionType.SALE ? 'text-green-600' : 'text-red-600'}`}>₹{(transaction.grandTotal || 0).toLocaleString('en-IN')}</p>
          </div>
        </div>

        {transaction.description && (
          <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Description</p>
            <p className="text-sm text-gray-600 italic">{transaction.description}</p>
          </div>
        )}

        <div className="overflow-x-auto rounded-2xl border border-gray-100">
          <table className="w-full text-left border-collapse min-w-[400px]">
            <thead className="bg-gray-50">
              <tr className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                <th className="p-4">Item</th>
                <th className="p-4 text-center">Bags</th>
                <th className="p-4 text-right">Rate</th>
                <th className="p-4 text-right">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {transaction.items.map((item, idx) => (
                <tr key={idx} className="text-sm">
                  <td className="p-4 font-bold text-gray-700">{item.itemName}</td>
                  <td className="p-4 text-center font-bold text-gray-500">{item.bags}</td>
                  <td className="p-4 text-right font-bold text-gray-500">₹{(item.rate || 0).toLocaleString('en-IN')}</td>
                  <td className="p-4 text-right font-black text-gray-800">₹{(item.total || 0).toLocaleString('en-IN')}</td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50/50">
              <tr className="text-sm font-black">
                <td colSpan={3} className="p-4 text-right text-gray-400 uppercase text-[10px]">Subtotal</td>
                <td className="p-4 text-right text-gray-800">₹{(transaction.subTotal || 0).toLocaleString('en-IN')}</td>
              </tr>
              {transaction.discount > 0 && (
                <tr className="text-sm font-black">
                  <td colSpan={3} className="p-4 text-right text-gray-400 uppercase text-[10px]">Discount</td>
                  <td className="p-4 text-right text-red-500">-₹{(transaction.discount || 0).toLocaleString('en-IN')}</td>
                </tr>
              )}
            </tfoot>
          </table>
        </div>

        <div className="flex gap-4">
          <button 
            onClick={() => onEdit(transaction)}
            className="flex-1 py-5 bg-indigo-600 text-white font-black text-sm uppercase tracking-widest rounded-[2rem] shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 flex items-center justify-center gap-3"
          >
            <i className="fas fa-edit"></i>
            Edit
          </button>
          <button 
            onClick={() => {
              if (confirm('Are you sure you want to delete this transaction?')) {
                onDelete(transaction.id);
              }
            }}
            className="flex-1 py-5 bg-red-50 text-red-600 font-black text-sm uppercase tracking-widest rounded-[2rem] border border-red-100 hover:bg-red-100 transition-all active:scale-95 flex items-center justify-center gap-3"
          >
            <i className="fas fa-trash-can"></i>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
};

export default TransactionDetails;
