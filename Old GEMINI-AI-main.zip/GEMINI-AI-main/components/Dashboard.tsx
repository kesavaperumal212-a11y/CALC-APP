
import React, { useRef, useMemo, useState } from 'react';
import { Transaction, TransactionType, SalaryTransaction, Expense } from '../types.ts';
import { db } from '../db.ts';

interface DashboardProps {
  transactions: Transaction[];
  salaryTransactions: SalaryTransaction[];
  expenses: Expense[];
  onNewSale: () => void;
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onDataImported: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  transactions, 
  salaryTransactions, 
  expenses, 
  onDelete, 
  onEdit, 
  onNewSale, 
  onDataImported 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const stats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    let totalSales = 0;
    let totalPurchases = 0;
    let monthSales = 0;
    let monthPurchases = 0;

    transactions.forEach(t => {
      const tDate = new Date(t.date);
      const isThisMonth = tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear;

      if (t.type === TransactionType.SALE) {
        totalSales += t.grandTotal;
        if (isThisMonth) monthSales += t.grandTotal;
      } else {
        totalPurchases += t.grandTotal;
        if (isThisMonth) monthPurchases += t.grandTotal;
      }
    });

    expenses.forEach(e => {
      const eDate = new Date(e.date);
      const isThisMonth = eDate.getMonth() === currentMonth && eDate.getFullYear() === currentYear;
      totalPurchases += e.amount;
      if (isThisMonth) monthPurchases += e.amount;
    });

    salaryTransactions.forEach(s => {
      const sDate = new Date(s.date);
      const isThisMonth = sDate.getMonth() === currentMonth && sDate.getFullYear() === currentYear;
      totalPurchases += s.amount;
      if (isThisMonth) monthPurchases += s.amount;
    });

    return {
      totalSales,
      totalPurchases,
      monthEarnings: monthSales - monthPurchases,
      monthSales,
      monthPurchases,
      monthName: now.toLocaleString('default', { month: 'long' })
    };
  }, [transactions]);

  const handleExportAllData = async () => {
    setIsProcessing(true);
    try {
      const data = {
        parties: db.getParties(),
        items: db.getItems(),
        transactions: db.getTransactions(),
        expenses: db.getExpenses(),
        expenseCategories: db.getExpenseCategories(),
        employees: db.getEmployees(),
        attendance: db.getAttendance(),
        salaryTransactions: db.getSalaryTransactions()
      };
      const fileName = `EarningPro_Backup_${new Date().toISOString().split('T')[0]}.json`;
      const jsonStr = JSON.stringify(data, null, 2);
      
      // 1. Always offer File Download first
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // 2. Also offer Share/Clipboard option
      if (navigator.canShare && navigator.share) {
        try {
          const file = new File([blob], fileName, { type: 'application/json' });
          if (navigator.canShare({ files: [file] })) {
            await navigator.share({
              files: [file],
              title: 'Earning Pro Backup',
              text: 'Database Backup File'
            });
          } else {
            await navigator.share({
              title: 'Backup Data',
              text: jsonStr
            });
          }
        } catch (e) {
          await navigator.clipboard.writeText(jsonStr);
          alert('Backup file downloaded AND data copied to clipboard!');
        }
      } else {
        await navigator.clipboard.writeText(jsonStr);
        alert('Backup file downloaded AND data copied to clipboard!');
      }

    } catch (err) {
      console.error('Export failed', err);
      alert('Export failed. Please check app permissions.');
    } finally {
      setIsProcessing(false);
    }
  };

  const recentActivity = useMemo(() => {
    const combined: any[] = [
      ...transactions.map(t => ({ ...t, activityType: 'TRANSACTION' })),
      ...expenses.map(e => ({ ...e, activityType: 'EXPENSE' })),
      ...salaryTransactions.map(s => ({ ...s, activityType: 'SALARY' }))
    ];

    return combined.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 15);
  }, [transactions, expenses, salaryTransactions]);

  const handleImportAllData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.parties && data.items && data.transactions) {
          if (confirm('Replace all local data with this backup?')) {
            db.saveParties(data.parties);
            db.saveItems(data.items);
            db.saveTransactions(data.transactions);
            onDataImported();
            alert('Restore Successful!');
          }
        } else {
          alert('Invalid backup file structure.');
        }
      } catch (err) {
        alert('Could not read backup file.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="p-4 space-y-4 select-none animate-in fade-in duration-300">
      {/* Monthly Profit Highlight */}
      <div className="bg-indigo-600 p-5 rounded-[2rem] shadow-xl shadow-indigo-100 text-white relative overflow-hidden">
        <div className="relative z-10">
          <p className="text-indigo-100 text-[9px] font-black uppercase tracking-widest mb-1 opacity-80">
            {stats.monthName} {new Date().getFullYear()} Report
          </p>
          <div className="flex items-center gap-2">
            <span className="text-3xl font-black tracking-tighter">₹{(stats.monthEarnings || 0).toLocaleString('en-IN')}</span>
            <div className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider ${stats.monthEarnings >= 0 ? 'bg-green-400 text-green-950' : 'bg-red-400 text-red-950'}`}>
              {stats.monthEarnings >= 0 ? 'Profit' : 'Loss'}
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-white/10 pt-3">
            <div>
              <p className="text-[8px] text-indigo-200 font-bold uppercase tracking-widest">Sales</p>
              <p className="text-base font-black">₹{(stats.monthSales || 0).toLocaleString('en-IN')}</p>
            </div>
            <div>
              <p className="text-[8px] text-indigo-200 font-bold uppercase tracking-widest">Purchase</p>
              <p className="text-base font-black">₹{(stats.monthPurchases || 0).toLocaleString('en-IN')}</p>
            </div>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>
      </div>

      {/* Lifetime Stats */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm">
          <p className="text-[8px] text-gray-400 font-black uppercase tracking-wider mb-0.5">Lifetime Sales</p>
          <p className="text-lg font-black text-green-600">₹{(stats.totalSales || 0).toLocaleString('en-IN')}</p>
        </div>
        <div className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm">
          <p className="text-[8px] text-gray-400 font-black uppercase tracking-wider mb-0.5">Lifetime Purchase</p>
          <p className="text-lg font-black text-red-600">₹{(stats.totalPurchases || 0).toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Backup/Restore Actions */}
      <div className="flex gap-3 px-2">
        <button 
          onClick={handleExportAllData} 
          disabled={isProcessing}
          className="flex-1 py-4 bg-gray-50 text-gray-700 text-[10px] font-black uppercase tracking-widest rounded-2xl border border-gray-200 active:bg-gray-200 active:scale-95 transition-all flex items-center justify-center gap-2"
        >
          {isProcessing ? (
            <i className="fas fa-spinner fa-spin text-indigo-600"></i>
          ) : (
            <i className="fas fa-share-nodes text-indigo-600"></i>
          )}
          Backup Data
        </button>
        <button onClick={() => fileInputRef.current?.click()} className="flex-1 py-4 bg-gray-50 text-gray-700 text-[10px] font-black uppercase tracking-widest rounded-2xl border border-gray-200 active:bg-gray-200 active:scale-95 transition-all flex items-center justify-center gap-2">
          <i className="fas fa-file-arrow-up text-indigo-600"></i> Restore
        </button>
        <input type="file" ref={fileInputRef} onChange={handleImportAllData} className="hidden" accept=".json" />
      </div>

      <div className="flex justify-between items-center px-2 pt-2">
        <h2 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Recent Activity</h2>
        <button onClick={onNewSale} className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-full uppercase tracking-tighter active:scale-90 transition-transform">Add Entry +</button>
      </div>

      <div className="space-y-3 pb-6">
        <div className="grid grid-cols-12 px-4 text-[8px] font-black text-gray-400 uppercase tracking-widest">
          <div className="col-span-6">Activity</div>
          <div className="col-span-3 text-right">Sale</div>
          <div className="col-span-3 text-right">Purchase</div>
        </div>
        {recentActivity.length === 0 ? (
          <div className="text-center py-12 text-gray-300 italic text-sm">No activity yet.</div>
        ) : (
          recentActivity.map(act => {
            if (act.activityType === 'TRANSACTION') {
              const tx = act as Transaction;
              return (
                <div 
                  key={tx.id} 
                  onClick={() => onEdit(tx)}
                  className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 grid grid-cols-12 items-center active:bg-gray-50 transition-colors cursor-pointer"
                >
                  <div className="col-span-6">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[7px] font-black px-1 py-0.5 rounded-md uppercase tracking-tighter ${tx.type === TransactionType.SALE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {tx.type}
                      </span>
                      <span className="text-[9px] text-gray-400 font-bold">{new Date(tx.date).toLocaleDateString([], {month:'short', day:'numeric'})}</span>
                    </div>
                    <h3 className="font-black text-gray-800 text-xs truncate pr-2">{tx.partyName}</h3>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-green-600 truncate">
                      {tx.type === TransactionType.SALE ? `₹${(tx.grandTotal || 0).toLocaleString('en-IN')}` : '-'}
                    </p>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-red-600 truncate">
                      {tx.type === TransactionType.PURCHASE ? `₹${(tx.grandTotal || 0).toLocaleString('en-IN')}` : '-'}
                    </p>
                  </div>
                </div>
              );
            } else if (act.activityType === 'EXPENSE') {
              const exp = act as Expense;
              return (
                <div key={exp.id} className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 grid grid-cols-12 items-center">
                  <div className="col-span-6">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[7px] font-black px-1 py-0.5 rounded-md uppercase tracking-tighter bg-orange-100 text-orange-700">
                        EXPENSE
                      </span>
                      <span className="text-[9px] text-gray-400 font-bold">{new Date(exp.date).toLocaleDateString([], {month:'short', day:'numeric'})}</span>
                    </div>
                    <h3 className="font-black text-gray-800 text-xs truncate pr-2">{exp.categoryName}</h3>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-green-600">-</p>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-red-600 truncate">
                      ₹{(exp.amount || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>
              );
            } else {
              const sal = act as SalaryTransaction;
              return (
                <div key={sal.id} className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 grid grid-cols-12 items-center">
                  <div className="col-span-6">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[7px] font-black px-1 py-0.5 rounded-md uppercase tracking-tighter bg-blue-100 text-blue-700">
                        STAFF {sal.type}
                      </span>
                      <span className="text-[9px] text-gray-400 font-bold">{new Date(sal.date).toLocaleDateString([], {month:'short', day:'numeric'})}</span>
                    </div>
                    <h3 className="font-black text-gray-800 text-xs truncate pr-2">Salary</h3>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-green-600">-</p>
                  </div>
                  <div className="col-span-3 text-right">
                    <p className="font-black text-[11px] text-red-600 truncate">
                      ₹{(sal.amount || 0).toLocaleString('en-IN')}
                    </p>
                  </div>
                </div>
              );
            }
          })
        )}
      </div>
    </div>
  );
};

export default Dashboard;
