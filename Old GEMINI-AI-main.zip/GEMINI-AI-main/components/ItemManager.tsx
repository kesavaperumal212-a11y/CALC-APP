
import React, { useState } from 'react';
import { Item } from '../types';

interface ItemManagerProps {
  items: Item[];
  onAdd: (item: Item) => void;
  onUpdate: (item: Item) => void;
  onDelete: (id: string) => void;
}

const ItemManager: React.FC<ItemManagerProps> = ({ items, onAdd, onUpdate, onDelete }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', defaultKg: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const itemData = { 
      id: editingId || Date.now().toString(), 
      name: formData.name, 
      defaultKg: formData.defaultKg ? Number(formData.defaultKg) : undefined 
    };

    if (editingId) {
      onUpdate(itemData);
    } else {
      onAdd(itemData);
    }

    setFormData({ name: '', defaultKg: '' });
    setEditingId(null);
    setShowForm(false);
  };

  const handleEdit = (item: Item) => {
    setFormData({ name: item.name, defaultKg: item.defaultKg?.toString() || '' });
    setEditingId(item.id);
    setShowForm(true);
  };

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Product List</h2>
        <button 
          onClick={() => {
            if (showForm) {
              setEditingId(null);
              setFormData({ name: '', defaultKg: '' });
            }
            setShowForm(!showForm);
          }}
          className={`p-2 rounded-full transition-all ${showForm ? 'bg-red-100 text-red-600 rotate-45' : 'bg-indigo-600 text-white shadow-lg'}`}
        >
          <i className="fas fa-plus"></i>
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-8 bg-gray-50 p-5 rounded-2xl border border-gray-200 shadow-inner space-y-4">
          <h3 className="text-sm font-bold uppercase text-gray-500 mb-2">{editingId ? 'Edit Item' : 'Create New Item'}</h3>
          <p className="text-[10px] text-gray-400 -mt-2">Primary Unit: Bags | Secondary Unit: Kg</p>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Item Name *</label>
            <input 
              required
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.name}
              onChange={(e) => setFormData({...formData, name: e.target.value})}
              placeholder="e.g. Basmati Rice"
            />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Default Weight (Kg/Bag)</label>
            <input 
              type="number"
              className="w-full p-3 border border-gray-200 rounded-xl bg-white"
              value={formData.defaultKg}
              onChange={(e) => setFormData({...formData, defaultKg: e.target.value})}
              placeholder="e.g. 26"
            />
          </div>
          <button type="submit" className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl shadow-md">
            {editingId ? 'Update Product' : 'Add Product'}
          </button>
        </form>
      )}

      <div className="grid grid-cols-2 gap-3">
        {items.length === 0 ? (
          <div className="col-span-2 py-10 text-center text-gray-400 italic">No products added.</div>
        ) : (
          items.map(i => (
            <div key={i.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm relative group hover:border-indigo-200 transition-colors">
              <h3 className="font-bold text-gray-800 break-words">{i.name}</h3>
              <p className="text-[10px] text-indigo-500 font-bold uppercase mt-1">
                {i.defaultKg ? `${i.defaultKg}kg Standard` : 'Custom weights'}
              </p>
              <div className="absolute top-2 right-2 flex gap-1">
                <button 
                  onClick={() => handleEdit(i)}
                  className="text-gray-300 hover:text-indigo-500 transition-colors p-1"
                >
                  <i className="fas fa-edit text-xs"></i>
                </button>
                <button 
                  onClick={() => onDelete(i.id)}
                  className="text-gray-300 hover:text-red-500 transition-colors p-1"
                >
                  <i className="fas fa-minus-circle"></i>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ItemManager;
