
import React, { useMemo, useState } from 'react';
import { Employee, Attendance } from '../types';

interface AttendanceReportProps {
  employees: Employee[];
  attendance: Attendance[];
}

const AttendanceReport: React.FC<AttendanceReportProps> = ({ employees, attendance }) => {
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const monthName = new Date(selectedYear, selectedMonth).toLocaleString('default', { month: 'long' });

  const reportData = useMemo(() => {
    return employees.map(emp => {
      const monthRecords = attendance.filter(a => {
        const d = new Date(a.date);
        return a.employeeId === emp.id && d.getMonth() === selectedMonth && d.getFullYear() === selectedYear;
      });

      const present = monthRecords.filter(r => r.status === 'PRESENT').length;
      const absent = monthRecords.filter(r => r.status === 'ABSENT').length;
      const halfday = monthRecords.filter(r => r.status === 'HALFDAY').length;
      const late = monthRecords.filter(r => r.status === 'LATE').length;
      const totalCredits = present + (halfday * 0.5);

      return {
        ...emp,
        present,
        absent,
        halfday,
        late,
        totalCredits
      };
    });
  }, [employees, attendance, selectedMonth, selectedYear]);

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-black text-gray-800 tracking-tight">Attendance Report</h2>
        <div className="flex gap-2">
          <select 
            value={selectedMonth} 
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="text-[10px] font-black bg-white border border-gray-100 rounded-lg p-1"
          >
            {Array.from({ length: 12 }).map((_, i) => (
              <option key={i} value={i}>{new Date(0, i).toLocaleString('default', { month: 'short' })}</option>
            ))}
          </select>
          <select 
            value={selectedYear} 
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="text-[10px] font-black bg-white border border-gray-100 rounded-lg p-1"
          >
            {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-gray-100 shadow-xl shadow-gray-100/50 overflow-hidden">
        <div className="bg-indigo-600 p-4 text-white">
          <h3 className="text-xs font-black uppercase tracking-widest">{monthName} Summary</h3>
          <p className="text-[10px] opacity-80">28+ Credits = Green Mark</p>
        </div>
        
        <div className="divide-y divide-gray-50">
          {reportData.map(data => (
            <div key={data.id} className="p-4 flex justify-between items-center">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-black text-gray-800 text-sm">{data.name}</h4>
                  {data.totalCredits >= 28 && (
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                  )}
                </div>
                <div className="flex gap-2 mt-1">
                  <span className="text-[9px] font-bold text-green-600 bg-green-50 px-1.5 py-0.5 rounded">P: {data.present}</span>
                  <span className="text-[9px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded">A: {data.absent}</span>
                  <span className="text-[9px] font-bold text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded">H: {data.halfday}</span>
                </div>
              </div>
              <div className="text-right">
                <p className={`text-lg font-black ${data.totalCredits >= 28 ? 'text-green-600' : 'text-indigo-600'}`}>
                  {data.totalCredits}
                </p>
                <p className="text-[8px] text-gray-400 font-bold uppercase tracking-tighter">Total Credits</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-indigo-50 p-6 rounded-[2rem] border border-indigo-100">
        <h4 className="text-[10px] font-black text-indigo-900 uppercase tracking-widest mb-3">Report Legend</h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-[10px] font-bold text-indigo-700">Qualified (28+ Credits)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded bg-orange-100"></div>
            <span className="text-[10px] font-bold text-indigo-700">Half Day = 0.5 Credit</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AttendanceReport;
