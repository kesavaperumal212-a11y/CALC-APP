
export enum TransactionType {
  SALE = 'SALE',
  PURCHASE = 'PURCHASE'
}

export interface Party {
  id: string;
  name: string;
  address?: string;
  phone?: string;
}

export interface Item {
  id: string;
  name: string;
  defaultKg?: number; // Optional secondary unit weight
}

export interface TransactionItem {
  id: string;
  itemId: string;
  itemName: string;
  bags: number;
  kgPerBag?: number;
  rate: number;
  total: number;
}

export interface Transaction {
  id: string;
  date: string;
  type: TransactionType;
  partyId: string;
  partyName: string;
  items: TransactionItem[];
  grandTotal: number;
  description?: string;
}

export interface SalaryTransaction {
  id: string;
  employeeId: string;
  date: string;
  amount: number;
  type: 'ADVANCE' | 'SALARY_PAYMENT';
  note?: string;
}

export interface Employee {
  id: string;
  name: string;
  phone?: string;
  salary?: number;
}

export interface Attendance {
  id: string;
  employeeId: string;
  employeeName: string;
  date: string; // ISO string (date only)
  status: 'PRESENT' | 'ABSENT' | 'LATE' | 'HALFDAY';
  shift: 'MORNING' | 'NIGHT';
  note?: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
}

export interface Expense {
  id: string;
  categoryId: string;
  categoryName: string;
  date: string;
  amount: number;
  note?: string;
}

export type ViewState = 'dashboard' | 'transaction' | 'parties' | 'items' | 'reports' | 'attendance' | 'employees' | 'attendanceReport' | 'salary' | 'expenses' | 'transaction_details';
