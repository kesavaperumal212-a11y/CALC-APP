
import React, { useState, useEffect } from 'react';
import { ViewState, Party, Item, Transaction, TransactionType, Employee, Attendance, SalaryTransaction, Expense, ExpenseCategory } from './types.ts';
import { db } from './db.ts';
import { syncService } from './syncService.ts';
import Dashboard from './components/Dashboard.tsx';
import TransactionForm from './components/TransactionForm.tsx';
import PartyManager from './components/PartyManager.tsx';
import ItemManager from './components/ItemManager.tsx';
import ReportManager from './components/ReportManager.tsx';
import AttendanceManager from './components/AttendanceManager.tsx';
import EmployeeManager from './components/EmployeeManager.tsx';
import AttendanceReport from './components/AttendanceReport.tsx';
import SalaryManager from './components/SalaryManager.tsx';
import ExpenseManager from './components/ExpenseManager.tsx';
import TransactionDetails from './components/TransactionDetails.tsx';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [parties, setParties] = useState<Party[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [salaryTransactions, setSalaryTransactions] = useState<SalaryTransaction[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [expenseCategories, setExpenseCategories] = useState<ExpenseCategory[]>([]);

  // Edit states
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [viewingTransaction, setViewingTransaction] = useState<Transaction | null>(null);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

  // Sync state
  const [syncId, setSyncId] = useState(syncService.getRoomId() || '');
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [isSyncConnected, setIsSyncConnected] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);

  const loadData = () => {
    setParties(db.getParties());
    setItems(db.getItems());
    setTransactions(db.getTransactions());
    setEmployees(db.getEmployees());
    setAttendance(db.getAttendance());
    setSalaryTransactions(db.getSalaryTransactions());
    setExpenses(db.getExpenses());
    setExpenseCategories(db.getExpenseCategories());
  };

  useEffect(() => {
    loadData();

    // Connect to sync service
    syncService.connect(
      (data) => {
        if (data) {
          db.saveParties(data.parties || []);
          db.saveItems(data.items || []);
          db.saveTransactions(data.transactions || []);
          db.saveExpenses(data.expenses || []);
          db.saveExpenseCategories(data.expenseCategories || []);
          db.saveEmployees(data.employees || []);
          db.saveAttendance(data.attendance || []);
          db.saveSalaryTransactions(data.salaryTransactions || []);
          loadData();
        }
      },
      (connected, error) => {
        setIsSyncConnected(connected);
        setSyncError(error || null);
      }
    );

    return () => syncService.disconnect();
  }, []);

  const handleSyncUpdate = () => {
    syncService.broadcastUpdate();
  };

  const handleSaveParty = (party: Party) => {
    const exists = parties.find(p => p.id === party.id);
    let updated;
    if (exists) {
      updated = parties.map(p => p.id === party.id ? party : p);
    } else {
      updated = [...parties, party];
    }
    setParties(updated);
    db.saveParties(updated);
    handleSyncUpdate();
  };

  const handleDeleteParty = (id: string) => {
    const hasTransactions = transactions.some(t => t.partyId === id);
    if (hasTransactions) {
      alert("Cannot delete party because they have associated transactions.");
      return;
    }
    const updated = parties.filter(p => p.id !== id);
    setParties(updated);
    db.saveParties(updated);
    handleSyncUpdate();
  };

  const handleSaveItem = (item: Item) => {
    const exists = items.find(i => i.id === item.id);
    let updated;
    if (exists) {
      updated = items.map(i => i.id === item.id ? item : i);
    } else {
      updated = [...items, item];
    }
    setItems(updated);
    db.saveItems(updated);
    handleSyncUpdate();
  };

  const handleDeleteItem = (id: string) => {
    const hasTransactions = transactions.some(t => t.items.some(item => item.itemId === id));
    if (hasTransactions) {
      alert("Cannot delete product because it is used in existing transactions.");
      return;
    }
    const updated = items.filter(i => i.id !== id);
    setItems(updated);
    db.saveItems(updated);
    handleSyncUpdate();
  };

  const handleSaveTransaction = (tx: Transaction) => {
    const exists = transactions.find(t => t.id === tx.id);
    let updated;
    if (exists) {
      updated = transactions.map(t => t.id === tx.id ? tx : t);
    } else {
      updated = [tx, ...transactions];
    }
    setTransactions(updated);
    db.saveTransactions(updated);
    setEditingTransaction(null);
    setCurrentView('dashboard');
    handleSyncUpdate();
  };

  const handleDeleteTransaction = (id: string) => {
    const updated = transactions.filter(t => t.id !== id);
    setTransactions(updated);
    db.saveTransactions(updated);
    setViewingTransaction(null);
    setCurrentView('dashboard');
    handleSyncUpdate();
  };

  const handleEditTransaction = (tx: Transaction) => {
    setViewingTransaction(tx);
    setCurrentView('transaction_details');
  };

  const handleConfirmEditTransaction = (tx: Transaction) => {
    setEditingTransaction(tx);
    setViewingTransaction(null);
    setCurrentView('transaction');
  };

  // Employee Handlers
  const handleSaveEmployee = (emp: Employee) => {
    const exists = employees.find(e => e.id === emp.id);
    let updated;
    if (exists) {
      updated = employees.map(e => e.id === emp.id ? emp : e);
    } else {
      updated = [...employees, emp];
    }
    setEmployees(updated);
    db.saveEmployees(updated);
    handleSyncUpdate();
  };

  const handleDeleteEmployee = (id: string) => {
    const hasAttendance = attendance.some(a => a.employeeId === id);
    const hasSalaryTx = salaryTransactions.some(s => s.employeeId === id);
    if (hasAttendance || hasSalaryTx) {
      alert("Cannot delete employee because they have associated attendance or salary records.");
      return;
    }
    const updated = employees.filter(e => e.id !== id);
    setEmployees(updated);
    db.saveEmployees(updated);
    handleSyncUpdate();
  };

  // Attendance Handlers
  const handleSaveAttendance = (records: Attendance[]) => {
    // Merge new records with existing ones, replacing for the same employee/date/shift
    const updated = [...attendance];
    records.forEach(newRec => {
      const idx = updated.findIndex(r => 
        r.employeeId === newRec.employeeId && 
        r.date.split('T')[0] === newRec.date.split('T')[0] &&
        r.shift === newRec.shift
      );
      if (idx > -1) {
        updated[idx] = newRec;
      } else {
        updated.push(newRec);
      }
    });
    setAttendance(updated);
    db.saveAttendance(updated);
    handleSyncUpdate();
  };

  // Salary Handlers
  const handleSaveSalaryTransaction = (tx: SalaryTransaction) => {
    const updated = [tx, ...salaryTransactions];
    setSalaryTransactions(updated);
    db.saveSalaryTransactions(updated);
    handleSyncUpdate();
  };

  const handleDeleteSalaryTransaction = (id: string) => {
    const updated = salaryTransactions.filter(t => t.id !== id);
    setSalaryTransactions(updated);
    db.saveSalaryTransactions(updated);
    handleSyncUpdate();
  };

  // Expense Handlers
  const handleSaveExpense = (exp: Expense) => {
    const exists = expenses.find(e => e.id === exp.id);
    let updated;
    if (exists) {
      updated = expenses.map(e => e.id === exp.id ? exp : e);
    } else {
      updated = [exp, ...expenses];
    }
    setExpenses(updated);
    db.saveExpenses(updated);
    setEditingExpense(null);
    handleSyncUpdate();
  };

  const handleDeleteExpense = (id: string) => {
    const updated = expenses.filter(e => e.id !== id);
    setExpenses(updated);
    db.saveExpenses(updated);
    handleSyncUpdate();
  };

  const handleSaveExpenseCategory = (cat: ExpenseCategory) => {
    const updated = [...expenseCategories, cat];
    setExpenseCategories(updated);
    db.saveExpenseCategories(updated);
    handleSyncUpdate();
  };

  const handleDeleteExpenseCategory = (id: string) => {
    const hasExpenses = expenses.some(e => e.categoryId === id);
    if (hasExpenses) {
      alert("Cannot delete category because it has associated expenses.");
      return;
    }
    const updated = expenseCategories.filter(c => c.id !== id);
    setExpenseCategories(updated);
    db.saveExpenseCategories(updated);
    handleSyncUpdate();
  };

  const handleSyncIdSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (syncId.trim()) {
      syncService.setRoomId(syncId.trim());
      setShowSyncModal(false);
      alert('Sync ID set successfully!');
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-white overflow-hidden relative">
      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 transition-opacity"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full w-64 bg-white shadow-2xl z-50 transform transition-transform duration-300 ease-in-out ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 space-y-8">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-black text-indigo-600 tracking-tighter leading-tight">SRI ABIRAMI<br/>RICE INDUSTRIES</h2>
              </div>
              <button onClick={() => setIsSidebarOpen(false)} className="text-gray-400 hover:text-gray-600 p-2">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <p className="text-[8px] text-gray-400 font-bold uppercase tracking-widest border-b border-gray-100 pb-4">Premium Quality Rice • Kalambur</p>
          </div>
          
          <nav className="space-y-2">
            <button 
              onClick={() => { setCurrentView('parties'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'parties' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <i className="fas fa-users text-lg"></i>
              <span className="text-sm">Parties</span>
            </button>
            <button 
              onClick={() => { setCurrentView('items'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'items' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <i className="fas fa-boxes text-lg"></i>
              <span className="text-sm">Products</span>
            </button>
            <button 
              onClick={() => { setCurrentView('expenses'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'expenses' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
            >
              <i className="fas fa-receipt text-lg"></i>
              <span className="text-sm">Expenses</span>
            </button>

            <div className="pt-4 mt-4 border-t border-gray-100">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 px-4">Staff Management</p>
              <button 
                onClick={() => { setCurrentView('attendance'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'attendance' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <i className="fas fa-list-check text-lg"></i>
                <span className="text-sm">Attendance</span>
              </button>
              <button 
                onClick={() => { setCurrentView('attendanceReport'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'attendanceReport' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <i className="fas fa-file-invoice text-lg"></i>
                <span className="text-sm">Attendance Report</span>
              </button>
              <button 
                onClick={() => { setCurrentView('salary'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'salary' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <i className="fas fa-wallet text-lg"></i>
                <span className="text-sm">Salary & Advance</span>
              </button>
              <button 
                onClick={() => { setCurrentView('employees'); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${currentView === 'employees' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                <i className="fas fa-user-gear text-lg"></i>
                <span className="text-sm">Manage Employees</span>
              </button>
              <button 
                onClick={() => { setShowSyncModal(true); setIsSidebarOpen(false); }}
                className="w-full flex items-center gap-4 p-4 rounded-2xl transition-all text-gray-500 hover:bg-gray-50 group"
              >
                <div className="relative">
                  <i className="fas fa-sync text-lg"></i>
                  <div className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-white ${isSyncConnected ? 'bg-emerald-500' : 'bg-red-500'}`}></div>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-sm">Cross-Device Sync</span>
                  <span className={`text-[9px] font-bold uppercase tracking-widest ${isSyncConnected ? 'text-emerald-600' : 'text-red-600'}`}>
                    {isSyncConnected ? 'Connected' : 'Disconnected'}
                  </span>
                </div>
              </button>
            </div>
          </nav>
        </div>
      </aside>

      {/* Header */}
      <header className="bg-indigo-600 text-white shadow-md z-10 shrink-0 pt-[env(safe-area-inset-top)]">
        <div className="flex justify-between items-center h-14 px-4">
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 -ml-2 hover:bg-indigo-700 rounded-xl transition-colors active:scale-90"
            >
              <i className="fas fa-bars text-lg"></i>
            </button>
            <div className="flex items-center gap-2">
              <div className="flex flex-col">
                <h1 className="text-xs font-black tracking-tight uppercase leading-none">Sri Abirami</h1>
                <span className="text-[7px] font-bold opacity-80 tracking-widest uppercase">Rice Industries</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <button 
              onClick={() => setCurrentView('reports')}
              className={`p-2 hover:bg-indigo-700 rounded-xl transition-colors active:scale-90 flex items-center gap-2 ${currentView === 'reports' ? 'bg-indigo-700' : ''}`}
            >
              <i className="fas fa-chart-line text-lg"></i>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto">
        {currentView === 'dashboard' && (
          <Dashboard 
            transactions={transactions} 
            salaryTransactions={salaryTransactions}
            expenses={expenses}
            onNewSale={() => {
              setEditingTransaction(null);
              setCurrentView('transaction');
            }}
            onEdit={handleEditTransaction}
            onDelete={handleDeleteTransaction}
            onDataImported={loadData}
          />
        )}
        {currentView === 'transaction' && (
          <TransactionForm 
            parties={parties} 
            items={items} 
            initialData={editingTransaction || undefined}
            onSave={handleSaveTransaction}
            onCancel={() => {
              setEditingTransaction(null);
              setCurrentView('dashboard');
            }}
          />
        )}
        {currentView === 'transaction_details' && viewingTransaction && (
          <TransactionDetails 
            transaction={viewingTransaction}
            onEdit={handleConfirmEditTransaction}
            onDelete={handleDeleteTransaction}
            onBack={() => {
              setViewingTransaction(null);
              setCurrentView('dashboard');
            }}
          />
        )}
        {currentView === 'parties' && (
          <PartyManager 
            parties={parties} 
            onAdd={handleSaveParty} 
            onUpdate={handleSaveParty}
            onDelete={handleDeleteParty}
          />
        )}
        {currentView === 'items' && (
          <ItemManager 
            items={items} 
            onAdd={handleSaveItem} 
            onUpdate={handleSaveItem}
            onDelete={handleDeleteItem}
          />
        )}
        {currentView === 'reports' && (
          <ReportManager 
            transactions={transactions} 
            salaryTransactions={salaryTransactions}
            expenses={expenses}
          />
        )}
        {currentView === 'attendance' && (
          <AttendanceManager 
            employees={employees}
            attendance={attendance}
            onSave={handleSaveAttendance}
            onManageEmployees={() => setCurrentView('employees')}
          />
        )}
        {currentView === 'attendanceReport' && (
          <AttendanceReport 
            employees={employees}
            attendance={attendance}
          />
        )}
        {currentView === 'salary' && (
          <SalaryManager 
            employees={employees}
            attendance={attendance}
            salaryTransactions={salaryTransactions}
            onSaveTransaction={handleSaveSalaryTransaction}
            onDeleteTransaction={handleDeleteSalaryTransaction}
          />
        )}
        {currentView === 'expenses' && (
          <ExpenseManager 
            expenses={expenses}
            categories={expenseCategories}
            editingExpense={editingExpense}
            onAddExpense={handleSaveExpense}
            onEditExpense={setEditingExpense}
            onDeleteExpense={handleDeleteExpense}
            onAddCategory={handleSaveExpenseCategory}
            onDeleteCategory={handleDeleteExpenseCategory}
            onCancelEdit={() => setEditingExpense(null)}
          />
        )}
        {currentView === 'employees' && (
          <EmployeeManager 
            employees={employees}
            onAdd={handleSaveEmployee}
            onUpdate={handleSaveEmployee}
            onDelete={handleDeleteEmployee}
            onBack={() => setCurrentView('attendance')}
          />
        )}
      </main>

      {/* Sync Modal */}
      {showSyncModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] w-full max-w-md p-8 space-y-6 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-black text-gray-800 tracking-tight">Sync Devices</h2>
              <button onClick={() => setShowSyncModal(false)} className="text-gray-400 p-2"><i className="fas fa-times"></i></button>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed">
              Enter a unique <b>Sync ID</b> to connect multiple devices. All devices with the same ID will stay in sync automatically.
            </p>

            {!isSyncConnected && (
              <div className="bg-red-50 p-4 rounded-2xl border border-red-100 flex items-center gap-3">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse shrink-0"></div>
                <p className="text-[10px] text-red-700 font-bold leading-tight">
                  Connection issue: {syncError || 'Attempting to reconnect...'}
                </p>
              </div>
            )}
            
            <div className="bg-blue-50 p-4 rounded-2xl border border-blue-100">
              <p className="text-[10px] text-blue-700 font-bold leading-tight">
                <i className="fas fa-info-circle mr-2"></i>
                Important: Both devices must use the <b>exact same URL</b> to sync.
              </p>
            </div>

            <form onSubmit={handleSyncIdSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Your Sync ID</label>
                <input 
                  type="text" 
                  value={syncId}
                  onChange={(e) => setSyncId(e.target.value)}
                  placeholder="e.g. my-business-2024"
                  className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl font-bold text-indigo-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  required
                />
              </div>
              <button 
                type="submit"
                className="w-full py-5 bg-indigo-600 text-white font-black text-sm uppercase tracking-widest rounded-3xl shadow-xl shadow-indigo-200 active:scale-95 transition-transform"
              >
                Connect & Sync
              </button>
            </form>

            {isSyncConnected && syncId && (
              <button 
                onClick={() => {
                  handleSyncUpdate();
                  alert('Data broadcasted to all devices!');
                }}
                className="w-full py-4 bg-emerald-50 text-emerald-600 font-bold text-xs uppercase tracking-widest rounded-2xl border border-emerald-100 hover:bg-emerald-100 transition-colors"
              >
                <i className="fas fa-upload mr-2"></i>
                Push Local Data to Sync
              </button>
            )}

            <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
              <p className="text-[10px] text-amber-700 font-bold leading-tight">
                <i className="fas fa-triangle-exclamation mr-2"></i>
                Warning: Joining a room will overwrite your current local data with the room's data.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="shrink-0 bg-white border-t border-gray-100 flex justify-around items-center h-[calc(4rem+env(safe-area-inset-bottom))] z-20 shadow-[0_-2px_15px_rgba(0,0,0,0.03)] pb-[env(safe-area-inset-bottom)]">
        <button 
          onClick={() => setCurrentView('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-all ${currentView === 'dashboard' ? 'text-indigo-600 font-bold' : 'text-gray-400 opacity-60'}`}
        >
          <i className="fas fa-home mb-1 text-xl"></i>
          <span className="text-[10px] font-black uppercase tracking-tighter">Home</span>
        </button>
        <button 
          onClick={() => {
            setEditingTransaction(null);
            setCurrentView('transaction');
          }}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-all ${currentView === 'transaction' ? 'text-indigo-600 font-bold' : 'text-gray-400 opacity-60'}`}
        >
          <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg shadow-indigo-200 -mt-6 border-4 border-white">
            <i className="fas fa-plus text-white text-lg"></i>
          </div>
          <span className="text-[10px] font-black uppercase tracking-tighter mt-1">Add Entry</span>
        </button>
        <button 
          onClick={() => setCurrentView('reports')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-all ${currentView === 'reports' ? 'text-indigo-600 font-bold' : 'text-gray-400 opacity-60'}`}
        >
          <i className="fas fa-chart-pie mb-1 text-xl"></i>
          <span className="text-[10px] font-black uppercase tracking-tighter">Reports</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
