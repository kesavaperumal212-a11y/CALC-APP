
import React, { useRef } from 'react';
import { Transaction, TransactionType } from '../types';
import { db } from '../db';

interface DashboardProps {
  transactions: Transaction[];
  onNewSale: () => void;
  onDelete: (id: string) => void;
  onDataImported: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ transactions, onNewSale, onDelete, onDataImported }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalSales = transactions
    .filter(t => t.type === TransactionType.SALE)
    .reduce((sum, t) => sum + t.grandTotal, 0);

  const totalPurchases = transactions
    .filter(t => t.type === TransactionType.PURCHASE)
    .reduce((sum, t) => sum + t.grandTotal, 0);

  const handleExportAllData = () => {
    const data = {
      parties: db.getParties(),
      items: db.getItems(),
      transactions: db.getTransactions()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `EarningCalc_Backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportAllData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.parties && data.items && data.transactions) {
          if (confirm('This will replace your current data with the backup. Continue?')) {
            db.saveParties(data.parties);
            db.saveItems(data.items);
            db.saveTransactions(data.transactions);
            onDataImported();
            alert('Data imported successfully!');
          }
        } else {
          alert('Invalid backup file format.');
        }
      } catch (err) {
        alert('Error reading backup file.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="p-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-green-50 p-4 rounded-xl border border-green-100 shadow-sm">
          <p className="text-xs text-green-600 font-semibold uppercase">Total Sales</p>
          <p className="text-xl font-bold text-green-700">₹{totalSales.toLocaleString()}</p>
        </div>
        <div className="bg-red-50 p-4 rounded-xl border border-red-100 shadow-sm">
          <p className="text-xs text-red-600 font-semibold uppercase">Total Purchase</p>
          <p className="text-xl font-bold text-red-700">₹{totalPurchases.toLocaleString()}</p>
        </div>
      </div>

      {/* Backup/Restore Bar */}
      <div className="flex gap-2 mb-6">
        <button 
          onClick={handleExportAllData}
          className="flex-1 py-2 bg-gray-100 text-gray-600 text-[10px] font-bold uppercase rounded-lg border border-gray-200 hover:bg-gray-200 transition-colors"
        >
          <i className="fas fa-download mr-1"></i> Backup Data
        </button>
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="flex-1 py-2 bg-gray-100 text-gray-600 text-[10px] font-bold uppercase rounded-lg border border-gray-200 hover:bg-gray-200 transition-colors"
        >
          <i className="fas fa-upload mr-1"></i> Restore Data
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleImportAllData} 
          className="hidden" 
          accept=".json"
        />
      </div>

      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold text-gray-800">Recent Transactions</h2>
        <button 
          onClick={onNewSale}
          className="text-sm font-medium text-indigo-600 hover:text-indigo-800"
        >
          New Transaction
        </button>
      </div>

      {transactions.length === 0 ? (
        <div className="text-center py-12 px-4 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-200">
          <i className="fas fa-receipt text-4xl text-gray-300 mb-4"></i>
          <p className="text-gray-500 italic">No transactions recorded yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {transactions.map(tx => (
            <div key={tx.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center group transition-all hover:shadow-md">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${tx.type === TransactionType.SALE ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {tx.type}
                  </span>
                  <span className="text-xs text-gray-400">{new Date(tx.date).toLocaleDateString()}</span>
                </div>
                <h3 className="font-bold text-gray-800">{tx.partyName}</h3>
                <p className="text-xs text-gray-500">{tx.items.length} item(s)</p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${tx.type === TransactionType.SALE ? 'text-green-600' : 'text-red-600'}`}>
                  ₹{tx.grandTotal.toLocaleString()}
                </p>
                <button 
                  onClick={() => onDelete(tx.id)}
                  className="text-red-400 hover:text-red-600 p-1 mt-1 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <i className="fas fa-trash-alt text-xs"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
