
import React, { useState, useEffect } from 'react';
import { Party, Item, Transaction, TransactionType, TransactionItem } from '../types';

interface TransactionFormProps {
  parties: Party[];
  items: Item[];
  onSave: (tx: Transaction) => void;
  onCancel: () => void;
}

const TransactionForm: React.FC<TransactionFormProps> = ({ parties, items, onSave, onCancel }) => {
  const [type, setType] = useState<TransactionType>(TransactionType.SALE);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [partyId, setPartyId] = useState('');
  const [txItems, setTxItems] = useState<TransactionItem[]>([]);
  
  // Current item being added
  const [currentItem, setCurrentItem] = useState({
    itemId: '',
    bags: 0,
    kgPerBag: 0,
    rate: 0
  });

  const selectedParty = parties.find(p => p.id === partyId);

  const handleAddItem = () => {
    if (!currentItem.itemId || currentItem.bags <= 0 || currentItem.rate <= 0) {
      alert('Please select an item and enter valid quantity and rate.');
      return;
    }

    const itemObj = items.find(i => i.id === currentItem.itemId);
    const newItem: TransactionItem = {
      id: Date.now().toString() + Math.random(),
      itemId: currentItem.itemId,
      itemName: itemObj?.name || 'Unknown',
      bags: currentItem.bags,
      kgPerBag: currentItem.kgPerBag || undefined,
      rate: currentItem.rate,
      total: currentItem.bags * currentItem.rate
    };

    setTxItems([...txItems, newItem]);
    setCurrentItem({ itemId: '', bags: 0, kgPerBag: 0, rate: 0 });
  };

  const handleRemoveItem = (id: string) => {
    setTxItems(txItems.filter(i => i.id !== id));
  };

  const grandTotal = txItems.reduce((sum, item) => sum + item.total, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!partyId) return alert('Select a party');
    if (txItems.length === 0) return alert('Add at least one item');

    const tx: Transaction = {
      id: 'TX-' + Date.now(),
      date: new Date(date).toISOString(),
      type,
      partyId,
      partyName: selectedParty?.name || 'Unknown',
      items: txItems,
      grandTotal
    };

    onSave(tx);
  };

  return (
    <div className="p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">New {type === TransactionType.SALE ? 'Sale' : 'Purchase'}</h2>
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button 
            onClick={() => setType(TransactionType.SALE)}
            className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${type === TransactionType.SALE ? 'bg-white text-green-600 shadow-sm' : 'text-gray-500'}`}
          >
            SALE
          </button>
          <button 
            onClick={() => setType(TransactionType.PURCHASE)}
            className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${type === TransactionType.PURCHASE ? 'bg-white text-red-600 shadow-sm' : 'text-gray-500'}`}
          >
            PURCHASE
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Date Selection */}
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Transaction Date *</label>
          <input 
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-xl bg-white shadow-sm focus:ring-2 focus:ring-indigo-500"
            required
          />
        </div>

        {/* Party Selection */}
        <div>
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Party Name *</label>
          <select 
            value={partyId}
            onChange={(e) => setPartyId(e.target.value)}
            className="w-full p-3 border border-gray-200 rounded-xl bg-white shadow-sm focus:ring-2 focus:ring-indigo-500"
            required
          >
            <option value="">Select Party</option>
            {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>

        {/* Item Entry Section - Lightened backgrounds */}
        <div className="bg-indigo-50/30 p-4 rounded-2xl border border-indigo-100 shadow-sm space-y-3">
          <div className="flex justify-between items-center border-b border-indigo-100 pb-2">
            <h3 className="text-sm font-bold text-indigo-900">Add Item</h3>
            <span className="text-[10px] text-indigo-400 font-medium">Bags x Rate</span>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-gray-400 uppercase">Item *</label>
              <select 
                value={currentItem.itemId}
                onChange={(e) => {
                  const item = items.find(i => i.id === e.target.value);
                  setCurrentItem({...currentItem, itemId: e.target.value, kgPerBag: item?.defaultKg || 0});
                }}
                className="w-full p-2 border border-gray-200 rounded-lg bg-white focus:border-indigo-500 transition-colors"
              >
                <option value="">Select Item</option>
                {items.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
              </select>
            </div>
            
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase">Bags (Qty) *</label>
              <input 
                type="number"
                value={currentItem.bags || ''}
                onChange={(e) => setCurrentItem({...currentItem, bags: Number(e.target.value)})}
                placeholder="Qty"
                className="w-full p-2 border border-gray-200 rounded-lg bg-white focus:border-indigo-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase">Weight (Kg)</label>
              <input 
                type="number"
                value={currentItem.kgPerBag || ''}
                onChange={(e) => setCurrentItem({...currentItem, kgPerBag: Number(e.target.value)})}
                placeholder="Ex: 26, 75"
                className="w-full p-2 border border-gray-200 rounded-lg bg-white focus:border-indigo-500 transition-colors"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-gray-400 uppercase">Rate (₹ per Bag) *</label>
              <input 
                type="number"
                value={currentItem.rate || ''}
                onChange={(e) => setCurrentItem({...currentItem, rate: Number(e.target.value)})}
                placeholder="₹"
                className="w-full p-2 border border-gray-200 rounded-lg bg-white focus:border-indigo-500 transition-colors"
              />
            </div>
          </div>

          <button 
            type="button"
            onClick={handleAddItem}
            className="w-full bg-white text-indigo-700 border border-indigo-200 py-2 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors shadow-sm"
          >
            <i className="fas fa-plus mr-2"></i> Add to List
          </button>
        </div>

        {/* Transaction Items List */}
        {txItems.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-gray-700">Transaction Summary</h3>
            {txItems.map(item => (
              <div key={item.id} className="bg-white p-3 rounded-xl border border-gray-100 flex justify-between items-center text-sm shadow-sm">
                <div>
                  <p className="font-bold">{item.itemName}</p>
                  <p className="text-xs text-gray-500">
                    {item.bags} Bags {item.kgPerBag ? `@ ${item.kgPerBag}kg` : ''} x ₹{item.rate}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold">₹{item.total.toLocaleString()}</span>
                  <button type="button" onClick={() => handleRemoveItem(item.id)} className="text-red-400 p-1">
                    <i className="fas fa-times-circle"></i>
                  </button>
                </div>
              </div>
            ))}
            <div className="pt-2 border-t flex justify-between items-center">
              <span className="text-lg font-bold">Total Amount</span>
              <span className="text-lg font-black text-indigo-600">₹{grandTotal.toLocaleString()}</span>
            </div>
          </div>
        )}

        {/* Form Actions */}
        <div className="flex gap-4 pt-4">
          <button 
            type="button" 
            onClick={onCancel}
            className="flex-1 py-4 border-2 border-gray-100 text-gray-400 font-bold rounded-2xl hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button 
            type="submit"
            className="flex-1 py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95"
          >
            Save Transaction
          </button>
        </div>
      </form>
    </div>
  );
};

export default TransactionForm;
