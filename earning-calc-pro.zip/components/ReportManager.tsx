
import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType } from '../types';

interface ReportManagerProps {
  transactions: Transaction[];
}

const ReportManager: React.FC<ReportManagerProps> = ({ transactions }) => {
  const [filterType, setFilterType] = useState<'ALL' | TransactionType>('ALL');
  const [search, setSearch] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  // Transform data for flattened report view (item level)
  const reportData = useMemo(() => {
    const flattened = transactions.flatMap(tx => 
      tx.items.map(item => ({
        txId: tx.id,
        date: tx.date,
        type: tx.type,
        party: tx.partyName,
        itemName: item.itemName,
        bags: item.bags,
        kg: item.kgPerBag || '-',
        rate: item.rate,
        total: item.total
      }))
    );

    return flattened.filter(row => {
      const rowDate = row.date.split('T')[0];
      const matchesType = filterType === 'ALL' || row.type === filterType;
      const matchesSearch = row.party.toLowerCase().includes(search.toLowerCase()) || 
                          row.itemName.toLowerCase().includes(search.toLowerCase());
      const matchesFromDate = !fromDate || rowDate >= fromDate;
      const matchesToDate = !toDate || rowDate <= toDate;
      
      return matchesType && matchesSearch && matchesFromDate && matchesToDate;
    });
  }, [transactions, filterType, search, fromDate, toDate]);

  const stats = useMemo(() => {
    return reportData.reduce((acc, row) => {
      if (row.type === TransactionType.SALE) acc.sales += row.total;
      else acc.purchases += row.total;
      return acc;
    }, { sales: 0, purchases: 0 });
  }, [reportData]);

  const handleExportCSV = () => {
    if (reportData.length === 0) return;

    // Removed Bags, Kg, and Rate from headers
    const headers = ['Date', 'Type', 'Party', 'Item', 'Sales Amt', 'Purchase Amt'];
    const csvContent = [
      headers.join(','),
      ...reportData.map(row => {
        const rowDate = new Date(row.date).toLocaleDateString();
        const salesAmt = row.type === TransactionType.SALE ? row.total : 0;
        const purchaseAmt = row.type === TransactionType.PURCHASE ? row.total : 0;
        return [
          `"${rowDate}"`,
          `"${row.type}"`,
          `"${row.party}"`,
          `"${row.itemName}"`,
          salesAmt,
          purchaseAmt
        ].join(',');
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Business_Report_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Filtering Header */}
      <div className="p-4 bg-gray-50 border-b border-gray-200 sticky top-0 z-10 space-y-4 shadow-sm">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <i className="fas fa-file-excel text-green-600"></i> Business Report
          </h2>
          <button 
            onClick={() => {
              setSearch('');
              setFromDate('');
              setToDate('');
              setFilterType('ALL');
            }}
            className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider"
          >
            Reset Filters
          </button>
        </div>
        
        <div className="flex flex-col gap-3">
          {/* Search */}
          <div className="relative">
            <i className="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            <input 
              className="w-full pl-10 pr-4 py-2 bg-white border border-gray-300 rounded-lg text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 transition-all outline-none"
              placeholder="Search party or item..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Date Range Selection */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">From</label>
              <input 
                type="date"
                className="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs outline-none focus:border-indigo-500"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">To</label>
              <input 
                type="date"
                className="w-full p-2 bg-white border border-gray-300 rounded-lg text-xs outline-none focus:border-indigo-500"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
              />
            </div>
          </div>

          {/* Type Filter */}
          <div className="flex bg-white rounded-lg border border-gray-300 p-1 shadow-sm">
            {['ALL', TransactionType.SALE, TransactionType.PURCHASE].map(t => (
              <button
                key={t}
                onClick={() => setFilterType(t as any)}
                className={`flex-1 py-1.5 text-[10px] font-bold rounded uppercase transition-all duration-200 ${filterType === t ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Mini Stats Bar */}
        <div className="grid grid-cols-3 gap-2 px-1 text-[10px] font-bold">
          <div className="bg-green-50 text-green-700 p-2 rounded-lg border border-green-100 flex flex-col items-center shadow-sm">
            <span className="opacity-70">Total Sales</span>
            <span className="text-xs">₹{stats.sales.toLocaleString()}</span>
          </div>
          <div className="bg-red-50 text-red-700 p-2 rounded-lg border border-red-100 flex flex-col items-center shadow-sm">
            <span className="opacity-70">Total Purchase</span>
            <span className="text-xs">₹{stats.purchases.toLocaleString()}</span>
          </div>
          <div className="bg-indigo-50 text-indigo-700 p-2 rounded-lg border border-indigo-100 flex flex-col items-center shadow-sm">
            <span className="opacity-70">Net Balance</span>
            <span className="text-xs">₹{(stats.sales - stats.purchases).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Excel-like Table Content */}
      <div className="overflow-auto flex-1 bg-white">
        <table className="min-w-full border-collapse text-[10px]">
          <thead>
            <tr className="bg-white border-b-2 border-gray-200 text-left uppercase text-gray-500 sticky top-0 z-20">
              <th className="p-3 border-r border-gray-100 whitespace-nowrap">Date</th>
              <th className="p-3 border-r border-gray-100 whitespace-nowrap">Party</th>
              <th className="p-3 border-r border-gray-100 whitespace-nowrap">Item</th>
              <th className="p-3 border-r border-gray-100 whitespace-nowrap text-right text-green-700 bg-green-50/30">Sales Amt</th>
              <th className="p-3 whitespace-nowrap text-right text-red-700 bg-red-50/30">Purchase Amt</th>
            </tr>
          </thead>
          <tbody>
            {reportData.map((row, idx) => (
              <tr key={idx} className={`border-b border-gray-50 hover:bg-indigo-50/30 transition-colors ${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}`}>
                <td className="p-3 border-r border-gray-50 whitespace-nowrap">{new Date(row.date).toLocaleDateString()}</td>
                <td className="p-3 border-r border-gray-50 font-medium text-gray-700">{row.party}</td>
                <td className="p-3 border-r border-gray-50 text-gray-600">{row.itemName}</td>
                <td className={`p-3 border-r border-gray-50 text-right font-bold ${row.type === TransactionType.SALE ? 'text-green-600' : 'text-gray-300'}`}>
                  {row.type === TransactionType.SALE ? `₹${row.total.toLocaleString()}` : '-'}
                </td>
                <td className={`p-3 text-right font-bold ${row.type === TransactionType.PURCHASE ? 'text-red-600' : 'text-gray-300'}`}>
                  {row.type === TransactionType.PURCHASE ? `₹${row.total.toLocaleString()}` : '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {reportData.length === 0 && (
          <div className="py-20 text-center">
            <i className="fas fa-receipt text-gray-200 text-5xl mb-4"></i>
            <p className="text-gray-400 italic">No matching records found.</p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="absolute bottom-20 right-4 flex flex-col gap-3">
        <button 
          onClick={handleExportCSV}
          className="bg-green-600 text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center hover:bg-green-700 active:scale-90 transition-all z-30 group"
          title="Export to Excel (CSV)"
        >
          <i className="fas fa-file-csv text-xl"></i>
          <span className="absolute right-16 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">Excel Export</span>
        </button>
        <button 
          onClick={() => window.print()} 
          className="bg-indigo-600 text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center hover:bg-indigo-700 active:scale-90 transition-all z-30 group"
          title="Print Report (PDF)"
        >
          <i className="fas fa-print text-xl"></i>
          <span className="absolute right-16 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">Print to PDF</span>
        </button>
      </div>
    </div>
  );
};

export default ReportManager;
