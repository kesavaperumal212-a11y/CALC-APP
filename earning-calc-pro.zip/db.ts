
import { Party, Item, Transaction } from './types';

const STORAGE_KEYS = {
  PARTIES: 'ecp_parties',
  ITEMS: 'ecp_items',
  TRANSACTIONS: 'ecp_transactions'
};

export const db = {
  saveParties: (parties: Party[]) => localStorage.setItem(STORAGE_KEYS.PARTIES, JSON.stringify(parties)),
  getParties: (): Party[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.PARTIES) || '[]'),
  
  saveItems: (items: Item[]) => localStorage.setItem(STORAGE_KEYS.ITEMS, JSON.stringify(items)),
  getItems: (): Item[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.ITEMS) || '[]'),
  
  saveTransactions: (txs: Transaction[]) => localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(txs)),
  getTransactions: (): Transaction[] => JSON.parse(localStorage.getItem(STORAGE_KEYS.TRANSACTIONS) || '[]'),
};
