
import React, { useState, useEffect } from 'react';
import { ViewState, Party, Item, Transaction, TransactionType } from './types';
import { db } from './db';
import Dashboard from './components/Dashboard';
import TransactionForm from './components/TransactionForm';
import PartyManager from './components/PartyManager';
import ItemManager from './components/ItemManager';
import ReportManager from './components/ReportManager';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewState>('dashboard');
  const [parties, setParties] = useState<Party[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  const loadData = () => {
    setParties(db.getParties());
    setItems(db.getItems());
    setTransactions(db.getTransactions());
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveParty = (party: Party) => {
    const updated = [...parties, party];
    setParties(updated);
    db.saveParties(updated);
  };

  const handleDeleteParty = (id: string) => {
    const updated = parties.filter(p => p.id !== id);
    setParties(updated);
    db.saveParties(updated);
  };

  const handleSaveItem = (item: Item) => {
    const updated = [...items, item];
    setItems(updated);
    db.saveItems(updated);
  };

  const handleDeleteItem = (id: string) => {
    const updated = items.filter(i => i.id !== id);
    setItems(updated);
    db.saveItems(updated);
  };

  const handleSaveTransaction = (tx: Transaction) => {
    const updated = [tx, ...transactions];
    setTransactions(updated);
    db.saveTransactions(updated);
    setCurrentView('dashboard');
  };

  const handleDeleteTransaction = (id: string) => {
    const updated = transactions.filter(t => t.id !== id);
    setTransactions(updated);
    db.saveTransactions(updated);
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-white shadow-2xl overflow-hidden relative">
      {/* Header */}
      <header className="bg-indigo-600 text-white p-4 shadow-md z-10">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold tracking-tight">Earning Calc Pro</h1>
          <button 
            onClick={() => setCurrentView('reports')}
            className="p-2 hover:bg-indigo-700 rounded-full transition-colors"
          >
            <i className="fas fa-chart-line text-lg"></i>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24">
        {currentView === 'dashboard' && (
          <Dashboard 
            transactions={transactions} 
            onNewSale={() => setCurrentView('transaction')}
            onDelete={handleDeleteTransaction}
            onDataImported={loadData}
          />
        )}
        {currentView === 'transaction' && (
          <TransactionForm 
            parties={parties} 
            items={items} 
            onSave={handleSaveTransaction}
            onCancel={() => setCurrentView('dashboard')}
          />
        )}
        {currentView === 'parties' && (
          <PartyManager 
            parties={parties} 
            onAdd={handleSaveParty} 
            onDelete={handleDeleteParty}
          />
        )}
        {currentView === 'items' && (
          <ItemManager 
            items={items} 
            onAdd={handleSaveItem} 
            onDelete={handleDeleteItem}
          />
        )}
        {currentView === 'reports' && (
          <ReportManager transactions={transactions} />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 flex justify-around items-center h-16 z-20 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <button 
          onClick={() => setCurrentView('dashboard')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${currentView === 'dashboard' ? 'text-indigo-600' : 'text-gray-400'}`}
        >
          <i className="fas fa-home mb-1"></i>
          <span className="text-xs">Primary</span>
        </button>
        <button 
          onClick={() => setCurrentView('transaction')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${currentView === 'transaction' ? 'text-indigo-600' : 'text-gray-400'}`}
        >
          <i className="fas fa-plus-circle mb-1 text-lg"></i>
          <span className="text-xs">Transact</span>
        </button>
        <button 
          onClick={() => setCurrentView('parties')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${currentView === 'parties' ? 'text-indigo-600' : 'text-gray-400'}`}
        >
          <i className="fas fa-users mb-1"></i>
          <span className="text-xs">Parties</span>
        </button>
        <button 
          onClick={() => setCurrentView('items')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${currentView === 'items' ? 'text-indigo-600' : 'text-gray-400'}`}
        >
          <i className="fas fa-boxes mb-1"></i>
          <span className="text-xs">Items</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
