
export enum TransactionType {
  SALE = 'SALE',
  PURCHASE = 'PURCHASE'
}

export interface Party {
  id: string;
  name: string;
  address?: string;
  phone?: string;
}

export interface Item {
  id: string;
  name: string;
  defaultKg?: number; // Optional secondary unit weight
}

export interface TransactionItem {
  id: string;
  itemId: string;
  itemName: string;
  bags: number;
  kgPerBag?: number;
  rate: number;
  total: number;
}

export interface Transaction {
  id: string;
  date: string;
  type: TransactionType;
  partyId: string;
  partyName: string;
  items: TransactionItem[];
  grandTotal: number;
}

export type ViewState = 'dashboard' | 'transaction' | 'parties' | 'items' | 'reports';
